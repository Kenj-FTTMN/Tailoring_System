<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('../database/connection.php'); // Ensure this path is correct

// Fetch recent activities
$sql_activities = "SELECT r.first_name, r.last_name, a.activity, a.activity_time 
                   FROM recent_activities a
                   JOIN registration r ON a.user_id = r.user_id
                   ORDER BY a.activity_time DESC LIMIT 5";
$result_activities = $con->query($sql_activities);

// Fetch recent sales
$sql_sales = "SELECT * FROM orders ORDER BY created_at DESC LIMIT 5";
$result_sales = $con->query($sql_sales);
?>

<div class="pagetitle">
  <h1>Dashboard</h1>
</div>
<section class="section dashboard">
  <div class="row">
    <!-- Left side columns -->
    <div class="col-lg-8">
      <div class="row">
        <!-- Sales Card -->
        <div class="col-xxl-4 col-md-6">
          <div class="card info-card sales-card">
            <div class="card-body">
              <h5 class="card-title">Sales <span>| Today</span></h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-cart"></i>
                </div>
                <div class="ps-3">
                  <h6>145</h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                </div>
              </div>
            </div>
          </div>
        </div><!-- End Sales Card -->

        <!-- Revenue Card -->
        <div class="col-xxl-4 col-md-6">
          <div class="card info-card revenue-card">
            <div class="card-body">
              <h5 class="card-title">Revenue <span>| This Month</span></h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-currency-dollar"></i>
                </div>
                <div class="ps-3">
                  <h6>$3,264</h6>
                  <span class="text-success small pt-1 fw-bold">8%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                </div>
              </div>
            </div>
          </div>
        </div><!-- End Revenue Card -->

        <!-- Customers Card -->
        <div class="col-xxl-4 col-xl-12">
          <div class="card info-card customers-card">
            <div class="card-body">
              <h5 class="card-title">Customers <span>| This Year</span></h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-people"></i>
                </div>
                <div class="ps-3">
                  <h6>1244</h6>
                  <span class="text-danger small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">decrease</span>
                </div>
              </div>
            </div>
          </div>
        </div><!-- End Customers Card -->

        <!-- Reports -->
        <div class="col-12">
          <div class="card">
            <div class="card-body">
              <h5 class="card-title">Reports <span>/Today</span></h5>
              <!-- Line Chart -->
              <div id="reportsChart"></div>
              <script>
                // Initialize chart only when needed
                const initChart = () => {
                  const chartOptions = {
                    series: [{
                      name: 'Sales',
                      data: [31, 40, 28, 51, 42, 82, 56],
                    }, {
                      name: 'Revenue',
                      data: [11, 32, 45, 32, 34, 52, 41]
                    }],
                    chart: {
                      height: 350,
                      type: 'area',
                      toolbar: {
                        show: false
                      },
                    },
                    markers: {
                      size: 4
                    },
                    colors: ['#4154f1', '#2eca6a'],
                    fill: {
                      type: "gradient",
                      gradient: {
                        shadeIntensity: 1,
                        opacityFrom: 0.3,
                        opacityTo: 0.4,
                        stops: [0, 90, 100]
                      }
                    },
                    dataLabels: {
                      enabled: false
                    },
                    stroke: {
                      curve: 'smooth',
                      width: 2
                    },
                    xaxis: {
                      type: 'datetime',
                      categories: ["2018-09-19T00:00:00.000Z", "2018-09-19T01:30:00.000Z", "2018-09-19T02:30:00.000Z", "2018-09-19T03:30:00.000Z", "2018-09-19T04:30:00.000Z", "2018-09-19T05:30:00.000Z", "2018-09-19T06:30:00.000Z"]
                    },
                    tooltip: {
                      x: {
                        format: 'dd/MM/yy HH:mm'
                      },
                    }
                  };

                  new ApexCharts(document.querySelector("#reportsChart"), chartOptions).render();
                };

                // Load chart only when element is visible
                document.addEventListener('DOMContentLoaded', () => {
                  const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                      if (entry.isIntersecting) {
                        initChart();
                        observer.disconnect();
                      }
                    });
                  });
                  
                  const chartElement = document.querySelector("#reportsChart");
                  if (chartElement) {
                    observer.observe(chartElement);
                  }
                });
              </script>
            </div>
          </div>
        </div><!-- End Reports -->

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales">
            <div class="card-body">
              <h5 class="card-title">Recent Sales <span>| Today</span></h5>
              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Product</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total</th>
                    <th scope="col">Customer Email</th>
                    <th scope="col">Customer Address</th>
                    <th scope="col">Customer Phone</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = $result_sales->fetch_assoc()): ?>
                    <tr id="order-<?php echo $row['id']; ?>">
                      <th scope="row"><?php echo $row['id']; ?></th>
                      <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                      <td>₱<?php echo htmlspecialchars($row['price']); ?></td>
                      <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                      <td>₱<?php echo htmlspecialchars($row['total_amount']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_email']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_address']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_phone']); ?></td>
                      <td><span class="badge bg-<?php echo $row['status'] == 'pending' ? 'warning' : ($row['status'] == 'completed' ? 'primary' : 'secondary'); ?>"><?php echo ucfirst($row['status']); ?></span></td>
                      <td class="action-buttons">
                        <form class="update-order-form" data-order-id="<?php echo $row['id']; ?>" style="display:inline;">
                          <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                          <input type="hidden" name="status" value="completed">
                          <button type="submit" class="btn btn-success btn-sm">Done</button>
                        </form>
                        <form class="delete-order-form" data-order-id="<?php echo $row['id']; ?>" style="display:inline;">
                          <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                        </form>
                      </td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div><!-- End Recent Sales -->
      </div>
    </div><!-- End Left side columns -->

    <!-- Right side columns -->
    <div class="col-lg-4">
      <!-- Recent Activity -->
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Recent Activity <span>| Today</span></h5>
          <div class="activity">
            <?php while ($row = $result_activities->fetch_assoc()): ?>
              <div class="activity-item d-flex">
                <div class="activite-label"><?php echo time_elapsed_string($row['activity_time']); ?></div>
                <i class='bi bi-circle-fill activity-badge text-success align-self-start'></i>
                <div class="activity-content">
                  <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name'] . ' - ' . $row['activity']); ?>
                </div>
              </div>
            <?php endwhile; ?>
          </div>
        </div>
      </div><!-- End Recent Activity -->
    </div><!-- End Right side columns -->
  </div>
</section>

<?php
// Function to calculate time elapsed
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    $weeks = floor($diff->d / 7);
    $diff->d -= $weeks * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'w' => 'week',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );
    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>

<style>
  .action-buttons {
    white-space: nowrap;
  }
  .action-buttons form {
    display: inline-block;
    margin-right: 5px;
  }
  .action-buttons .btn {
    margin-bottom: 5px;
  }
</style>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Handle update order form submission
    document.querySelectorAll('.update-order-form').forEach(function(form) {
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        var orderId = form.getAttribute('data-order-id');
        var formData = new FormData(form);

        fetch('update_order.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.status === 'success') {
            document.querySelector('#order-' + orderId + ' .badge').classList.remove('bg-warning');
            document.querySelector('#order-' + orderId + ' .badge').classList.add('bg-primary');
            document.querySelector('#order-' + orderId + ' .badge').textContent = 'Completed';
          } else {
            alert('Failed to update order status. Please try again.');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Failed to update order status. Please try again.');
        });
      });
    });

    // Handle delete order form submission
    document.querySelectorAll('.delete-order-form').forEach(function(form) {
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        var orderId = form.getAttribute('data-order-id');
        var formData = new FormData(form);

        fetch('delete_order.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.status === 'success') {
            document.querySelector('#order-' + orderId).remove();
          } else {
            alert('Failed to delete order. Please try again.');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Failed to delete order. Please try again.');
        });
      });
    });
  });
</script>