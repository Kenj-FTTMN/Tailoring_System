<?php
// Remove session_start() since it's already started in admin_index.php
include('../database/connection.php'); // Ensure this path is correct

// Check if admin is logged in - remove header redirect since we're included in admin_index.php
if (!isset($_SESSION['user_id']) || $_SESSION['user_id'] != 1) {
    echo '<div class="alert alert-danger">Access denied. Please log in as admin.</div>';
    exit();
}

// Update appointment status if requested
if (isset($_POST['update_status'])) {
    $appointment_id = $_POST['appointment_id'];
    $new_status = $_POST['new_status'];
    $update_query = "UPDATE repair_appointments SET status = ? WHERE id = ?";
    $stmt = $con->prepare($update_query);
    $stmt->bind_param("si", $new_status, $appointment_id);
    $stmt->execute();
}

// Get filter parameters
$status_filter = isset($_GET['status']) ? $_GET['status'] : 'all';
$date_filter = isset($_GET['date']) ? $_GET['date'] : '';

// Build the query based on filters
$query = "SELECT * FROM repair_appointments WHERE 1=1";
if ($status_filter != 'all') {
    $query .= " AND status = '$status_filter'";
}
if ($date_filter != '') {
    $query .= " AND DATE(preferred_date) = '$date_filter'";
}
$query .= " ORDER BY preferred_date DESC";

$result = $con->query($query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Repair Appointments - Admin</title>
    <style>
        .appointment-card {
            margin-bottom: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .status-pending { 
            border-left: 4px solid #ffc107;
            background-color: #fff;
        }
        .status-approved { 
            border-left: 4px solid #198754;
            background-color: #fff;
        }
        .status-completed { 
            border-left: 4px solid #0d6efd;
            background-color: #fff;
        }
        .status-cancelled { 
            border-left: 4px solid #dc3545;
            background-color: #fff;
        }
        /* Filter styles */
        .filter-form {
            display: flex;
            gap: 10px;
            align-items: center;
        }
        .filter-form select,
        .filter-form input[type="date"] {
            border: 1px solid #dee2e6;
            border-radius: 4px;
            padding: 6px 12px;
            height: 38px;
        }
        .filter-form .form-select {
            width: 200px; /* Increase the width of the dropdown */
        }
        .filter-form .btn-apply {
            background-color: #0d6efd;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            cursor: pointer;
            min-width: 150px; /* Set minimum width */
        }
        .filter-form .btn-reset {
            background-color: #6c757d;
            color: white;
            border: none;
            padding: 8px 16px;
            border-radius: 4px;
            text-decoration: none;
            cursor: pointer;
            min-width: 120px; /* Set minimum width */
        }
        .filter-form .btn-apply:hover {
            background-color: #0b5ed7;
        }
        .filter-form .btn-reset:hover {
            background-color: #5c636a;
        }
        .text-center {
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container-fluid">
        <h2 class="mb-4">Repair Appointments</h2>

        <!-- Filters -->
        <div class="row mb-4">
            <div class="col-md-8">
                <form class="filter-form">
                    <input type="hidden" name="page" value="repairs">
                    <select name="status" class="form-select">
                        <option value="all" <?php echo $status_filter == 'all' ? 'selected' : ''; ?>>All Status</option>
                        <option value="pending" <?php echo $status_filter == 'pending' ? 'selected' : ''; ?>>Pending</option>
                        <option value="approved" <?php echo $status_filter == 'approved' ? 'selected' : ''; ?>>Approved</option>
                        <option value="completed" <?php echo $status_filter == 'completed' ? 'selected' : ''; ?>>Completed</option>
                        <option value="cancelled" <?php echo $status_filter == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                    </select>
                    <input type="date" name="date" class="form-control" value="<?php echo $date_filter; ?>">
                    <button type="submit" class="btn-apply"><i class="bi bi-filter"></i> Apply Filter</button>
                    <a href="admin_index.php?page=repairs" class="btn-reset"><i class="bi bi-x-circle"></i> Reset</a>
                </form>
            </div>
        </div>

        <!-- Appointments List -->
        <div class="row">
            <?php if ($result && $result->num_rows > 0): ?>
                <?php while($row = $result->fetch_assoc()): ?>
                    <div class="col-md-6">
                        <div class="card appointment-card status-<?php echo $row['status']; ?>">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name']); ?></h5>
                                <p class="card-text">
                                    <strong>Garment:</strong> <?php echo htmlspecialchars($row['garment_type']); ?><br>
                                    <strong>Repair Type:</strong> <?php echo htmlspecialchars($row['repair_type']); ?><br>
                                    <strong>Date:</strong> <?php echo date('F j, Y', strtotime($row['preferred_date'])); ?><br>
                                    <strong>Time:</strong> <?php echo htmlspecialchars($row['preferred_time']); ?><br>
                                    <strong>Status:</strong> <?php echo ucfirst($row['status']); ?><br>
                                    <strong>Contact:</strong> <?php echo htmlspecialchars($row['phone_number']); ?><br>
                                    <strong>Email:</strong> <?php echo htmlspecialchars($row['email']); ?>
                                </p>
                                <div class="mt-3">
                                    <button type="button" class="btn btn-primary btn-sm" data-bs-toggle="modal" data-bs-target="#detailsModal<?php echo $row['id']; ?>">
                                        View Details
                                    </button>
                                    <form action="" method="POST" class="d-inline">
                                        <input type="hidden" name="appointment_id" value="<?php echo $row['id']; ?>">
                                        <select name="new_status" class="form-select-sm d-inline" style="width: auto;">
                                            <option value="pending" <?php echo $row['status'] == 'pending' ? 'selected' : ''; ?>>Pending</option>
                                            <option value="approved" <?php echo $row['status'] == 'approved' ? 'selected' : ''; ?>>Approved</option>
                                            <option value="completed" <?php echo $row['status'] == 'completed' ? 'selected' : ''; ?>>Completed</option>
                                            <option value="cancelled" <?php echo $row['status'] == 'cancelled' ? 'selected' : ''; ?>>Cancelled</option>
                                        </select>
                                        <button type="submit" name="update_status" class="btn btn-success btn-sm">Update Status</button>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <!-- Details Modal -->
                        <div class="modal fade" id="detailsModal<?php echo $row['id']; ?>" tabindex="-1">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header">
                                        <h5 class="modal-title">Appointment Details</h5>
                                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                    </div>
                                    <div class="modal-body">
                                        <h6>Repair Description:</h6>
                                        <p><?php echo nl2br(htmlspecialchars($row['repair_description'])); ?></p>
                                        
                                        <h6>Additional Notes:</h6>
                                        <p><?php echo nl2br(htmlspecialchars($row['additional_notes'] ?? 'None')); ?></p>
                                        
                                        <h6>Appointment Created:</h6>
                                        <p><?php echo date('F j, Y g:i A', strtotime($row['created_at'])); ?></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            <?php else: ?>
                <div class="col">
                    <div class="alert alert-info">No appointments found.</div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</body>
</html>