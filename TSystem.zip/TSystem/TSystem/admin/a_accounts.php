<?php 
include '../database/connection.php';

$sql = "SELECT `user_id`, `first_name`, `last_name`, `birthday`, `address`, `contact_no`, `email`, `username` 
        FROM `registration` 
        WHERE `deleted_at` IS NULL";
$result = $con->query($sql);
?>

<div class="pagetitle">
  <h1>Manage Accounts</h1>
</div>
<table class="table datatable">
    <thead>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Birthday</th>
            <th>Address</th>
            <th>Contact Number</th>
            <th>Email</th>
            <th>Username</th>
            <th>Action</th>
        </tr>  
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr> 
            <td><?php echo $row['user_id']; ?></td>
            <td><?php echo $row['first_name']; ?></td>
            <td><?php echo $row['last_name']; ?></td>
            <td><?php echo $row['birthday']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['contact_no']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td>
                <a href="/TSystem/delete.php?id=<?php echo $row['user_id']; ?>" class="btn btn-danger">
                    <i class="bi bi-trash"></i> Delete
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>