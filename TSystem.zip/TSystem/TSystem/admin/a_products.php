<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('../database/connection.php'); // Ensure this path is correct

$notification = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create'])) {
        // Create Product
        $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
        $product_description = mysqli_real_escape_string($conn, $_POST['product_description']);
        $price = mysqli_real_escape_string($conn, $_POST['price']);
        $quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
        
        // Handle image upload
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            if (move_uploaded_file($_FILES['image']['tmp_name'], '../admin/' . $image)) {
                $notification = "Image uploaded successfully: " . $image;
            } else {
                $notification = "Failed to move uploaded file.";
            }
        } else {
            $notification = "Error uploading file: " . $_FILES['image']['error'];
        }

        $query = "INSERT INTO products (product_name, product_description, price, quantity, image) VALUES ('$product_name', '$product_description', '$price', '$quantity', '$image')";
        if (mysqli_query($conn, $query)) {
            $notification .= " Product added successfully.";
        } else {
            $notification .= " Error: " . mysqli_error($conn);
        }
    } elseif (isset($_POST['update'])) {
        // Update Product
        $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
        $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
        $product_description = mysqli_real_escape_string($conn, $_POST['product_description']);
        $price = mysqli_real_escape_string($conn, $_POST['price']);
        $quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
        
        // Handle image upload
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], '../admin/' . $image);
        }

        $query = "UPDATE products SET product_name='$product_name', product_description='$product_description', price='$price', quantity='$quantity'" . ($image ? ", image='$image'" : "") . " WHERE product_id='$product_id'";
        if (mysqli_query($conn, $query)) {
            $notification = "Product updated successfully.";
        } else {
            $notification = "Error: " . mysqli_error($conn);
        }
    } elseif (isset($_POST['delete'])) {
        // Delete Product
        $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
        $query = "DELETE FROM products WHERE product_id='$product_id'";
        if (mysqli_query($conn, $query)) {
            $notification = "Product deleted successfully.";
        } else {
            $notification = "Error: " . mysqli_error($conn);
        }
    }
}

$query = "SELECT * FROM products";
$result = mysqli_query($con, $query);
?>

<div class="container mt-4">
    <h2 class="text-center">Product Management</h2>
    <table class="table table-bordered table-striped mt-4">
        <thead class="thead-light">
            <tr>
                <th class="text-center" style="width: 10%;">Product ID</th>
                <th class="text-center" style="width: 15%;">Name</th>
                <th class="text-center" style="width: 35%;">Description</th>
                <th class="text-center" style="width: 10%;">Price</th>
                <th class="text-center" style="width: 10%;">Quantity</th>
                <th class="text-center" style="width: 20%;">Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <tr>
                    <td class="text-center"><?php echo $row['product_id']; ?></td>
                    <td><?php echo $row['product_name']; ?></td>
                    <td><?php echo $row['product_description']; ?></td>
                    <td class="text-center"><?php echo $row['price']; ?></td>
                    <td class="text-center"><?php echo $row['quantity']; ?></td>
                    <td class="text-center">
                        <form method="POST" style="display:inline;">
                            <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                            <button type="submit" name="delete" class="btn btn-danger btn-sm action-btn"><i class="bi bi-trash"></i> Delete</button>
                        </form>
                        <button onclick="editProduct(<?php echo $row['product_id']; ?>, '<?php echo addslashes($row['product_name']); ?>', '<?php echo addslashes($row['product_description']); ?>', '<?php echo $row['price']; ?>', '<?php echo $row['quantity']; ?>')" class="btn btn-warning btn-sm action-btn"><i class="bi bi-pencil-square"></i> Edit</button>
                        <button onclick="viewProduct('<?php echo addslashes($row['product_name']); ?>', '<?php echo addslashes($row['product_description']); ?>', '<?php echo $row['price']; ?>', '<?php echo $row['quantity']; ?>', '<?php echo $row['image']; ?>')" class="btn btn-info btn-sm action-btn" data-bs-toggle="modal" data-bs-target="#viewModal"><i class="bi bi-eye"></i> View</button>
                    </td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h3 class="mt-4">Add / Update Product</h3>
    <form method="POST" enctype="multipart/form-data">
        <input type="hidden" name="product_id" id="product_id">
        <div class="form-group">
            <label for="product_name" style="margin-top: 10px">Product Name:</label>
            <input type="text" name="product_name" id="product_name" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="product_description" style="margin-top: 10px">Description:</label>
            <textarea name="product_description" id="product_description" class="form-control"></textarea>
        </div>
        
        <div class="form-group">
            <label for="price" style="margin-top: 10px">Price:</label>
            <input type="number" name="price" id="price" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="quantity" style="margin-top: 10px">Quantity:</label>
            <input type="number" name="quantity" id="quantity" class="form-control" required>
        </div>
        
        <div class="form-group">
            <label for="image" style="margin-top: 10px">Product Image:</label>
            <input type="file" name="image" id="image" class="form-control" accept="image/*" required>
        </div>
        
        <button type="submit" name="create" class="btn btn-primary" style="margin-top: 37px;"><i class="bi bi-plus-circle"></i> Create Product</button>
        <button type="submit" name="update" class="btn btn-success" style="margin-top: 37px;"><i class="bi bi-check-circle"></i> Update Product</button>
    </form>
</div>

<!-- View Modal -->
<div class="modal fade" id="viewModal" tabindex="-1" aria-labelledby="viewModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="viewModalLabel">Product Details</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body text-center">
                <img id="viewProductImage" src="" alt="Product Image" class="img-fluid mb-3">
                <p><strong>Name:</strong> <span id="viewProductName"></span></p>
                <p><strong>Description:</strong> <span id="viewProductDescription"></span></p>
                <p><strong>Price:</strong> <span id="viewProductPrice"></span></p>
                <p><strong>Quantity:</strong> <span id="viewProductQuantity"></span></p>
            </div>
        </div>
    </div>
</div>

<script>
function editProduct(productId, productName, productDescription, price, quantity) {
    document.getElementById('product_id').value = productId;
    document.getElementById('product_name').value = productName;
    document.getElementById('product_description').value = productDescription;
    document.getElementById('price').value = price;
    document.getElementById('quantity').value = quantity;
}

function viewProduct(name, description, price, quantity, image) {
    document.getElementById('viewProductName').innerText = name;
    document.getElementById('viewProductDescription').innerText = description;
    document.getElementById('viewProductPrice').innerText = price;
    document.getElementById('viewProductQuantity').innerText = quantity;
    document.getElementById('viewProductImage').src = '../admin/' + image;
}

document.addEventListener("DOMContentLoaded", function() {
    const notification = "<?php echo $notification; ?>";
    if (notification) {
        alert(notification);
    }
});
</script>

<style>
.text-center {
    text-align: center;
}
.action-btn {
    margin-right: 5px;
}
.btn-danger {
    background-color: #dc3545;
    border-color: #dc3545;
}
.btn-warning {
    background-color: #ffc107;
    border-color: #ffc107;
}
.btn-info {
    background-color: #17a2b8;
    border-color: #17a2b8;
}
</style>