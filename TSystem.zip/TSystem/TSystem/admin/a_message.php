<div class="pagetitle">
    <h1>Messages</h1>
</div>
<?php 
// Use a relative path from the current directory
require_once('../database/connection.php');

// Fetch messages with error handling
try {
    $sql = "SELECT `name`, `email`, `message` FROM `message`";
    $result = mysqli_query($con, $sql);

    if (!$result) {
        throw new Exception("Query failed: " . mysqli_error($con));
    }
?>
<div class="inbox-container">
    <?php 
    if (mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)): 
    ?>
        <div class="message-item">
            <strong><i class="bi bi-person"></i> NAME:</strong> <?php echo htmlspecialchars($row['name']); ?><br>
            <strong><i class="bi bi-envelope"></i> EMAIL:</strong> <?php echo htmlspecialchars($row['email']); ?><br><br>
            <label for="message"><strong><i class="bi bi-chat-text"></i> Message:</strong></label>
            <textarea id="message" readonly><?php echo htmlspecialchars($row['message']); ?></textarea>
            <button class="reply-btn"><i class="bi bi-reply"></i> REPLY</button>
        </div>
    <?php 
        endwhile;
    } else {
        echo '<div class="alert alert-info"><i class="bi bi-info-circle"></i> No messages found.</div>';
    }
    ?>
</div>
<?php
} catch (Exception $e) {
    echo '<div class="alert alert-danger"><i class="bi bi-exclamation-triangle"></i> Error: ' . $e->getMessage() . '</div>';
}

// Close the connection
mysqli_close($con);
?>