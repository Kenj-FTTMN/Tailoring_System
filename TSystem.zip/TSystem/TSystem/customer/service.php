<?php
if (!isset($_GET['service_page'])) {
?>
<section id="services" class="services section">

  <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2>Services</h2>
    <div><span>Check Our</span> <span class="description-title">Services</span></div>
  </div>
  <!-- End Section Title -->

  <div class="container">
    <div class="row gy-4">

    <div class="col-lg-4 col-md-6 mt-4" data-aos="fade-up" data-aos-delay="100">
        <div class="service-item position-relative">
          <a href="customer_index.php?page=service&service_page=products" class="<?php echo ($_GET['service_page'] ?? '') === 'products' ? 'active' : ''; ?>">
            <h3 style="margin-left: 30px; margin-top: 30px;">Ready-Made</h3>
          </a>
          <p style="margin-top: 20px;">Ready-made clothes are mass-produced garments that are manufactured in standard sizes and sold in finished form, ready to wear.</p>
        </div>
      </div>
      <!-- End Service Item -->

      <div class="col-lg-4 col-md-6 mt-4" data-aos="fade-up" data-aos-delay="200">
        <div class="service-item position-relative">
        <a href="customer_index.php?page=service&service_page=custom" class="<?php echo ($_GET['service_page'] ?? '') === 'custom' ? 'active' : ''; ?>">
    <h3 style="margin-left: 30px; margin-top: 30px;">Custom-Made</h3>
</a>
          <p style="margin-top: 20px;">Custom-made clothes are garments tailored specifically to an individual's measurements, preferences, and style choices.</p>
        </div>
      </div>
      <!-- End Service Item -->

      <div class="col-lg-4 col-md-6 mt-4" data-aos="fade-up" data-aos-delay="300">
        <div class="service-item position-relative">
          <a href="customer_index.php?page=service&service_page=repair" class="<?php echo ($_GET['service_page'] ?? '') === 'repair' ? 'active' : ''; ?>">
            <h3 style="margin-left: 30px; margin-top: 30px;">Repair</h3>
          </a>
          <p style="margin-top: 20px;">Fixing damaged or worn-out garments to restore their functionality and appearance. This includes mending tears, replacing buttons, and reinforcing weak areas, extending the lifespan of clothing.</p>
        </div>
      </div>
      <!-- End Service Item -->

    </div>
  </div>
</section>
<?php
}

if (isset($_GET['service_page'])) {
    $service_page = $_GET['service_page'];
    switch ($service_page) {
        case 'products':
            include 'products.php';
            break;
        case 'custom':
            include 'custom.php';
            break;
        case 'repair':
            include 'repair.php';
            break;
    }
}
?>

