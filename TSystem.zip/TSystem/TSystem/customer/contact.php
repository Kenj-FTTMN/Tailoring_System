<section id="contact" class="contact section">

  <!-- Section Title -->
  <div class="container section-title" data-aos="fade-up">
    <h2 class="mb-4">Contact</h2>
    <div style="margin-bottom: -40px;">
      <span class="fw-bold">Need Help?</span> 
      <span class="description-title"> Contact Us</span>
    </div>
  </div>
  <!-- End Section Title -->

  <div class="container mt-4">
    <div class="row d-flex justify-content-center text-center">
      
      <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="100">
        <div class="card custom-shadow border-0 text-center p-4">
          <i class="bi bi-geo-alt" style="font-size: 50px; color:  #DCC3A1;"></i>
          <h5 class="mt-3">Address</h5>
          <p class="text-muted">Cagayan De Oro City</p>
        </div>
      </div>

      <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="200">
        <div class="card custom-shadow border-0 text-center p-4">
          <i class="bi bi-telephone" style="font-size: 50px; color:  #DCC3A1;"></i>
          <h5 class="mt-3">Call Us</h5>
          <p class="text-muted">09999999999</p>
        </div>
      </div>

      <div class="col-lg-4 col-md-6" data-aos="fade-up" data-aos-delay="300">
        <div class="card custom-shadow border-0 text-center p-4">
          <i class="bi bi-envelope" style="font-size: 50px; color:  #DCC3A1;"></i>
          <h5 class="mt-3">Email Us</h5>
          <p class="text-muted">example@email.com</p>
        </div>
      </div>
    </div>
</div>
</section>
