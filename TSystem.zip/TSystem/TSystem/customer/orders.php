<section class="contact section">
    <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row justify-content-center">
            
            <!-- Order Buttons (Placed on Top) -->
            <div class="col-12 text-center mb-7">
                <a href="add_order.php" class="px-4 py-2 fw-bold text-uppercase rounded-pill" 
                style="background-color: #f9f5ed; color: #d6b98c; font-size: 1.5rem; text-decoration: none; display: inline-block;">
                    Add New Order
                </a>
                <a href="view_orders.php" class="px-4 py-2 fw-bold text-uppercase rounded-pill ms-3" 
                style="background-color: #f9f5ed; color: #d6b98c; font-size: 1.5rem; text-decoration: none; display: inline-block;">
                    View Orders
                </a>
            </div>

            <!-- Info Boxes (Horizontally Aligned with Extra Margin) -->
            <div class="col-12 d-flex justify-content-center text-center" style="margin-top: 95px;">
                <div class="info-box mx-4 px-4 py-3">
                    <i class="bi bi-scissors" style="font-size: 2rem; color: #DCC3A1;"></i>
                    <h3>Custom Tailoring</h3>
                    <p>Professional tailoring services</p>
                </div>
                <div class="info-box mx-4 px-4 py-3">
                    <i class="bi bi-clock-history" style="font-size: 2rem; color: #DCC3A1;"></i>
                    <h3>Order Status</h3>
                    <p>Track your orders easily</p>
                </div>
                <div class="info-box mx-4 px-4 py-3">
                    <i class="bi bi-stars" style="font-size: 2rem; color: #DCC3A1;"></i>
                    <h3>Quality Guarantee</h3>
                    <p>Satisfaction guaranteed</p>
                </div>
            </div>

        </div>
    </div>
</section>
