<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('../database/connection.php'); // Ensure this path is correct

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
    $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
    $price = mysqli_real_escape_string($conn, $_POST['price']);
    $quantity = mysqli_real_escape_string($conn, $_POST['order_quantity']);
    $total_amount = $price * $quantity;
    $customer_name = mysqli_real_escape_string($conn, $_POST['customer_name']);
    $customer_email = mysqli_real_escape_string($conn, $_POST['customer_email']);
    $customer_address = mysqli_real_escape_string($conn, $_POST['customer_address']);
    $customer_phone = mysqli_real_escape_string($conn, $_POST['customer_phone']);

    $query = "INSERT INTO orders (product_id, product_name, price, quantity, total_amount, customer_name, customer_email, customer_address, customer_phone) 
              VALUES ('$product_id', '$product_name', '$price', '$quantity', '$total_amount', '$customer_name', '$customer_email', '$customer_address', '$customer_phone')";
    if (mysqli_query($conn, $query)) {
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error']);
    }
    exit();
}
?>