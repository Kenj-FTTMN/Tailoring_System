<section id="product-section" class="product section">
  
  <!-- Section Title -->
  <div class="container section-title text-center" data-aos="fade-up" style="margin-bottom: -50px">
    <h2 class="mb-4">Choose to Customize</h2>
    
    <!-- Garment Type Selection -->
    <div class="garment-selector mx-auto" style="max-width: 400px;">
      <select class="form-select form-select-lg mb-4" id="garmentType" name="garmentType" required style="background-color: #f9f5ed; border-color: #DCC3A1;">
        <option value="">Select Garment Type</option>
        <option value="dress" <?php echo (!isset($_GET['type']) || $_GET['type'] === 'dress') ? 'selected' : ''; ?>>Dress</option>
      </select>
    </div>
  </div>

  <div class="container mt-4">
    <?php
    $selected_type = isset($_GET['type']) ? $_GET['type'] : 'dress';
    
    if ($selected_type === 'polo') {
      include 'polo-shirt.php';
    } else {
      include 'dress.php';
    }
    ?>
  </div>
</section>

<script>
document.addEventListener("DOMContentLoaded", function () {
    // Garment type selection handler
    document.getElementById('garmentType').addEventListener('change', function() {
        const selectedType = this.value;
        window.location.href = `customer_index.php?page=custom&type=${selectedType}`;
    });
});
</script>

<style>
.form-select {
    border: 1px solid #DCC3A1;
}

.form-select:focus {
    border-color: #DCC3A1;
    box-shadow: 0 0 0 0.25rem rgba(220, 195, 161, 0.25);
}
</style>
