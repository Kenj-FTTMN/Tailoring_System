<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('../database/connection.php'); // Ensure this path is correct

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['create'])) {
        // Create Product
        $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
        $product_description = mysqli_real_escape_string($conn, $_POST['product_description']);
        $price = mysqli_real_escape_string($conn, $_POST['price']);
        $quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
        
        // Handle image upload
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], '../admin/' . $image);
        }

        $query = "INSERT INTO products (product_name, product_description, price, quantity, image) VALUES ('$product_name', '$product_description', '$price', '$quantity', '$image')";
        mysqli_query($conn, $query);
    } elseif (isset($_POST['update'])) {
        // Update Product
        $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
        $product_name = mysqli_real_escape_string($conn, $_POST['product_name']);
        $product_description = mysqli_real_escape_string($conn, $_POST['product_description']);
        $price = mysqli_real_escape_string($conn, $_POST['price']);
        $quantity = mysqli_real_escape_string($conn, $_POST['quantity']);
        
        // Handle image upload
        $image = null;
        if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
            $image = 'uploads/' . basename($_FILES['image']['name']);
            move_uploaded_file($_FILES['image']['tmp_name'], '../admin/' . $image);
        }

        $query = "UPDATE products SET product_name='$product_name', product_description='$product_description', price='$price', quantity='$quantity'" . ($image ? ", image='$image'" : "") . " WHERE product_id='$product_id'";
        mysqli_query($conn, $query);
    } elseif (isset($_POST['delete'])) {
        // Delete Product
        $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
        $query = "DELETE FROM products WHERE product_id='$product_id'";
        mysqli_query($conn, $query);
    }
}

$query = "SELECT * FROM products";
$result = mysqli_query($conn, $query);
?>

<section id="products-section" class="products section">
  <div class="container section-title text-center" data-aos="fade-up">
    <h2 class="mb-4">Featured Products</h2>
    <p class="text-muted">Shop our collection of ready-to-wear garments</p>
  </div>

  <div class="container mt-4">
    <!-- Featured Products Grid -->
    <div class="row g-4">
      <?php while ($row = mysqli_fetch_assoc($result)): ?>
        <div class="col-md-4" data-aos="fade-up">
          <div class="product-card" style="background-color: #f9f5ed; border-radius: 10px; overflow: hidden; height: 100%;">
            <div class="product-image" style="height: 650px; position: relative;">
              <img src="../admin/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['product_name']); ?>" class="img-fluid" 
                style="width: 100%; height: 100%; object-fit: contain; padding: 15px;">
              <div class="product-overlay">
                <form action="process_order.php" method="POST">
                  <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                  <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($row['product_name']); ?>">
                  <input type="hidden" name="price" value="<?php echo htmlspecialchars($row['price']); ?>">
                  <button type="submit" class="btn" style="background-color: #DCC3A1; color: white; font-weight: 500;">
                    Inquire Now
                  </button>
                </form>
              </div>
            </div>
            <div class="product-info p-4">
              <div class="d-flex justify-content-between align-items-start mb-2">
                <h5 style="color: #333;"><?php echo htmlspecialchars($row['product_name']); ?></h5>
                <span class="price" style="color: #DCC3A1; font-weight: 600; font-size: 1.2rem;">₱<?php echo htmlspecialchars($row['price']); ?></span>
              </div>
              <p class="mb-3" style="color: #666;"><?php echo htmlspecialchars($row['product_description']); ?></p>
              <div class="product-details">
                <div class="mb-2">
                  <span style="color: #888; font-size: 0.9rem;">
                    <i class="fas fa-tshirt me-2"></i>Available Quantity: <?php echo htmlspecialchars($row['quantity']); ?>
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      <?php endwhile; ?>
    </div>

    <!-- Services Section -->

  </div>
</section>

<style>
  @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');

  .product-card {
    transition: transform 0.3s ease, box-shadow 0.3s ease;
  }

  .product-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 4px 15px rgba(0,0,0,0.1);
  }

  .product-image {
    overflow: hidden;
  }

  .product-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0;
    transition: opacity 0.3s ease;
  }

  .product-card:hover .product-overlay {
    opacity: 1;
  }

  .price {
    background-color: rgba(220, 195, 161, 0.1);
    padding: 4px 12px;
    border-radius: 20px;
  }

  .btn {
    min-width: 120px;
  }

  .btn:hover {
    background-color: #c4a785 !important;
    transform: scale(1.05);
  }

  .product-details i {
    width: 20px;
    text-align: center;
  }
</style>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    // Initialize AOS
    AOS.init({
      duration: 800,
      easing: 'ease',
      once: true
    });
  });
</script>