/**
* Template Name: eStartup
* Template URL: https://bootstrapmade.com/estartup-bootstrap-landing-page-template/
* Updated: Aug 07 2024 with Bootstrap v5.3.3
* Author: BootstrapMade.com
* License: https://bootstrapmade.com/license/
*/

(function() {
  "use strict";

  /**
   * Apply .scrolled class to the body as the page is scrolled down
   */
  function toggleScrolled() {
    const selectBody = document.querySelector('body');
    const selectHeader = document.querySelector('#header');
    if (!selectHeader.classList.contains('scroll-up-sticky') && !selectHeader.classList.contains('sticky-top') && !selectHeader.classList.contains('fixed-top')) return;
    window.scrollY > 100 ? selectBody.classList.add('scrolled') : selectBody.classList.remove('scrolled');
  }

  document.addEventListener('scroll', toggleScrolled);
  window.addEventListener('load', toggleScrolled);

  /**
   * Mobile nav toggle
   */
  const mobileNavToggleBtn = document.querySelector('.mobile-nav-toggle');

  function mobileNavToogle() {
    document.querySelector('body').classList.toggle('mobile-nav-active');
    mobileNavToggleBtn.classList.toggle('bi-list');
    mobileNavToggleBtn.classList.toggle('bi-x');
  }
  mobileNavToggleBtn.addEventListener('click', mobileNavToogle);

  /**
   * Hide mobile nav on same-page/hash links
   */
  document.querySelectorAll('#navmenu a').forEach(navmenu => {
    navmenu.addEventListener('click', () => {
      if (document.querySelector('.mobile-nav-active')) {
        mobileNavToogle();
      }
    });

  });

  /**
   * Toggle mobile nav dropdowns
   */
  document.querySelectorAll('.navmenu .toggle-dropdown').forEach(navmenu => {
    navmenu.addEventListener('click', function(e) {
      e.preventDefault();
      this.parentNode.classList.toggle('active');
      this.parentNode.nextElementSibling.classList.toggle('dropdown-active');
      e.stopImmediatePropagation();
    });
  });

  /**
   * Preloader
   */
  const preloader = document.querySelector('#preloader');
  if (preloader) {
    window.addEventListener('load', () => {
      preloader.remove();
    });
  }

  /**
   * Scroll top button
   */
  let scrollTop = document.querySelector('.scroll-top');

  function toggleScrollTop() {
    if (scrollTop) {
      window.scrollY > 100 ? scrollTop.classList.add('active') : scrollTop.classList.remove('active');
    }
  }
  scrollTop.addEventListener('click', (e) => {
    e.preventDefault();
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });

  window.addEventListener('load', toggleScrollTop);
  document.addEventListener('scroll', toggleScrollTop);

  /**
   * Animation on scroll function and init
   */
  function aosInit() {
    AOS.init({
      duration: 600,
      easing: 'ease-in-out',
      once: true,
      mirror: false
    });
  }
  window.addEventListener('load', aosInit);

  /**
   * Initiate glightbox
   */
  const glightbox = GLightbox({
    selector: '.glightbox'
  });

  /**
   * Frequently Asked Questions Toggle
   */
  document.querySelectorAll('.faq-item h3, .faq-item .faq-toggle').forEach((faqItem) => {
    faqItem.addEventListener('click', () => {
      faqItem.parentNode.classList.toggle('faq-active');
    });
  });

  document.addEventListener("DOMContentLoaded", function () {
    const colorMap = {
        'black': {
            'scoop': '../assets/img/shift-black-u.png',
            'v': '../assets/img/shift-black.png',
            'round': '../assets/img/shift-black-round.png'
        },
        'rose': {
            'scoop': '../assets/img/shift-rose-u.png',
            'v': '../assets/img/shift-rose.png',
            'round': '../assets/img/shift-rose-round.png'
        },
        'waterlily': {
            'scoop': '../assets/img/shift-waterlily-u.png',
            'v': '../assets/img/shift-waterlily.png',
            'round': '../assets/img/shift-waterlily-round.png'
        }
    };

    const sheathColorMap = {
        'black': {
            'scoop': '../assets/img/sheath-black-u.png',
            'v': '../assets/img/sheath-black-v.png',
            'round': '../assets/img/sheath-black-round.png'
        },
        'rose': {
            'scoop': '../assets/img/sheath-rose-u.png',
            'v': '../assets/img/sheath-rose-v.png',
            'round': '../assets/img/sheath-rose-round.png'
        },
        'waterlily': {
            'scoop': '../assets/img/sheath-waterlily-u.png',
            'v': '../assets/img/sheath-waterlily-v.png',
            'round': '../assets/img/sheath-waterlily-round.png'
        }
    };

    const wrappedColorMap = {
        'black': {
            'v1': '../assets/img/wrap-black-v1.png',
            'v2': '../assets/img/wrap-black-v2.png'
        },
        'rose': {
            'v1': '../assets/img/wrap-rose-v1.png',
            'v2': '../assets/img/wrap-rose-v2.png'
        },
        'waterlily': {
            'v1': '../assets/img/wrap-waterlily-v1.png',
            'v2': '../assets/img/wrap-waterlily-v2.png'
        }
    };

    const dressStyleMap = {
        'shift': '../assets/img/shift-black-u.png',
        'sheath': '../assets/img/sheath-black-u.png',
        'wrapped': '../assets/img/wrap-black-v1.png'
    };

    // Initially hide the product image
    const productImage = document.getElementById("productImage");
    productImage.style.display = "none";

    // Disable neckline dropdown initially
    const necklineSelect = document.getElementById("neckline");
    necklineSelect.disabled = true;

    function updateNecklineOptions(style) {
        const necklineSelect = document.getElementById("neckline");
        necklineSelect.innerHTML = '';
        
        if (style === 'wrapped') {
            necklineSelect.innerHTML = `
                <option value="">Select Neckline</option>
                <option value="v1">V-Neck Middle</option>
                <option value="v2">V-Neck Deep</option>
            `;
        } else {
            necklineSelect.innerHTML = `
                <option value="">Select Neckline</option>
                <option value="scoop">Scoop Neck</option>
                <option value="v">V-Neck</option>
                <option value="round">Round Neck</option>
            `;
        }
    }

    function updateProductImage(style, color, neckline) {
        const productImage = document.getElementById("productImage");
        let imagePath = '';

        if (style === 'shift') {
            if (color && neckline) {
                imagePath = colorMap[color][neckline];
            } else if (color) {
                imagePath = colorMap[color]['scoop'];
            }
        } else if (style === 'sheath') {
            if (color && neckline && sheathColorMap[color]) {
                imagePath = sheathColorMap[color][neckline];
            } else if (color && sheathColorMap[color]) {
                imagePath = sheathColorMap[color]['scoop'];
            }
        } else if (style === 'wrapped') {
            if (color && neckline && wrappedColorMap[color]) {
                imagePath = wrappedColorMap[color][neckline];
            } else if (color && wrappedColorMap[color]) {
                imagePath = wrappedColorMap[color]['v1'];
            }
        } else if (dressStyleMap[style]) {
            imagePath = dressStyleMap[style];
        }

        if (imagePath) {
            productImage.style.opacity = "0";
            productImage.style.display = "block";
            setTimeout(() => {
                productImage.src = imagePath;
                productImage.style.opacity = "1";
            }, 300);
        }
    }

    function checkRequiredSelections() {
        const selectedStyle = document.getElementById("dressStyle").value;
        const selectedColor = document.getElementById("color").value;
        const selectedNeckline = document.getElementById("neckline").value;
        
        if (selectedStyle && selectedColor) {
            necklineSelect.disabled = false;
            updateProductImage(selectedStyle, selectedColor, selectedNeckline);
        } else {
            necklineSelect.disabled = true;
            if (selectedStyle && dressStyleMap[selectedStyle]) {
                updateProductImage(selectedStyle, null, null);
            } else {
                productImage.style.display = "none";
            }
        }
    }

    // Dress style selection handler
    document.getElementById('dressStyle').addEventListener('change', function() {
        const selectedStyle = this.value;
        updateNecklineOptions(selectedStyle);
        checkRequiredSelections();
    });

    // Color dropdown handler
    document.getElementById("color").addEventListener("change", function() {
        checkRequiredSelections();
    });

    // Color selection button handler
    document.querySelectorAll(".color-button").forEach(button => {
        button.addEventListener("click", function () {
            const selectedColor = this.getAttribute("data-color");
            const selectedStyle = document.getElementById("dressStyle").value;
            const selectedNeckline = document.getElementById("neckline").value;
            const colorSelect = document.getElementById("color");
            
            colorSelect.value = selectedColor;
            checkRequiredSelections();
        });
    });

    // Neckline dropdown handler
    document.getElementById("neckline").addEventListener("change", function() {
        const selectedNeckline = this.value;
        const selectedStyle = document.getElementById("dressStyle").value;
        const selectedColor = document.getElementById("color").value;
        
        if (selectedStyle && selectedColor && selectedNeckline) {
            updateProductImage(selectedStyle, selectedColor, selectedNeckline);
        }
    });

    // Fabric selection functionality
    document.querySelectorAll(".fabric-circle").forEach((circle, index) => {
        circle.addEventListener("click", function() {
            const fabricSelect = document.getElementById("fabricType");
            const fabricOptions = ["chiffon", "linen", "silk"];
            fabricSelect.value = fabricOptions[index];
            
            // Add visual feedback
            document.querySelectorAll(".fabric-circle").forEach(c => {
                c.style.borderColor = "#DCC3A1";
            });
            circle.style.borderColor = "#c4a785";
        });
    });

    // Form validation
    const form = document.querySelector('.needs-validation');
    form.addEventListener('submit', function(event) {
        if (!form.checkValidity()) {
            event.preventDefault();
            event.stopPropagation();
        }
        form.classList.add('was-validated');
    });
  });

})();