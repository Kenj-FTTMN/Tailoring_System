<?php
session_start();
include './database/connection.php';

if (isset($_POST['login-btn'])) {
    $username = $_POST["username"];
    $password = $_POST["password"];

    $sql = "SELECT * FROM registration WHERE username=? AND password=?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        // Set session variables
        $_SESSION['user_id'] = $row['user_id'];
        $_SESSION['username'] = $row['username'];
        $_SESSION['user_type'] = ($row['user_id'] == 1) ? 'admin' : 'customer';

        // Redirect based on user type
        if ($row['user_id'] == 1) {
            header('Location: admin/admin_index.php');
        } else {
            header('Location: customer/customer_index.php');
        }
        exit();
    } else {
        $error_message = "Invalid username or password";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Login - Tailoring System</title>
    <link href="assets/css/main.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--default-font);
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            background: var(--background-color);
        }

        .login-container {
            background: var(--surface-color);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            width: 350px;
            text-align: center;
        }

        .login-container h2 {
            margin-bottom: 20px;
            font-size: 24px;
            font-family: var(--heading-font);
            color: var(--heading-color);
        }

        .input-group {
            position: relative;
            margin: 15px 0;
        }

        .input-group input {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: 0.3s ease;
            outline: none;
        }

        .input-group input:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 5px rgba(220, 195, 161, 0.5);
        }

        .login-btn, .return-btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-size: 18px;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
            font-family: var(--nav-font);
        }

        .login-btn {
            background: var(--accent-color);
            color: var(--contrast-color);
        }

        .login-btn:hover {
            background: #c3a37d;
        }

        .return-btn {
            background: #ccc;
            color: var(--default-color);
        }

        .return-btn:hover {
            background: #bbb;
        }

        .forgot-password {
            display: block;
            margin: 10px 0;
            text-decoration: none;
            font-size: 14px;
            color: var(--accent-color);
        }

        .forgot-password:hover {
            text-decoration: underline;
        }

        .register-link {
            margin-top: 10px;
            font-size: 14px;
            color: var(--default-color);
        }

        .register-link a {
            color: var(--accent-color);
            text-decoration: none;
        }

        .register-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <h2>Login</h2>
        <?php if (isset($error_message)): ?>
            <div style="color: red; margin-bottom: 10px;"><?php echo $error_message; ?></div>
        <?php endif; ?>
        <form action="login.php" method="POST">
            <div class="input-group">
                <input type="text" name="username" placeholder="Username" required>
            </div>
            <div class="input-group">
                <input type="password" name="password" placeholder="Password" required>
            </div>
            <button type="submit" name="login-btn" class="login-btn">Login</button>
            <button type="button" class="return-btn" onclick="goBack()">Return</button>
        </form>
        <div class="register-link">
            Don't have an account? <a href="register.php">Register</a>
        </div>
    </div>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>
</body>
</html>