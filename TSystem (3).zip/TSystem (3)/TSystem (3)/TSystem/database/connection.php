<?php
$host = "localhost";
$username = "root";  // Default XAMPP username
$password = "";      // Default XAMPP password
$database = "tailoringsystem"; // Your database name

// Create connection with error handling
try {
    $con = mysqli_connect($host, $username, $password, $database);
    
    // Check connection
    if (!$con) {
        throw new Exception("Connection failed: " . mysqli_connect_error());
    }
} catch (Exception $e) {
    die("Database connection failed: " . $e->getMessage());
}
?>

<?php
// Database configuration
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "tailoringsystem";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Set charset to utf8mb4
$conn->set_charset("utf8mb4");

// Set timezone
date_default_timezone_set('Asia/Manila');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>