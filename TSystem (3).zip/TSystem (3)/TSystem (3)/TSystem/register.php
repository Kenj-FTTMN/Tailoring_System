<link href="assets/css/main.css" rel="stylesheet">
<style>
    * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: var(--default-font);
        }

        body {
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh; /* Allows scrolling if content exceeds screen height */
            background: var(--background-color);
            padding: 20px; /* Adds some spacing on smaller screens */
            overflow-y: auto; /* Enables vertical scrolling if necessary */
        }

        .register-container {
            background: var(--surface-color);
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0px 5px 15px rgba(0, 0, 0, 0.2);
            width: 400px;
            text-align: center;
        }

        .register-container h2 {
            margin-bottom: 20px;
            font-size: 24px;
            font-family: var(--heading-font);
            color: var(--heading-color);
        }

        .input-group {
            position: relative;
            margin: 10px 0;
            text-align: left;
        }

        .input-group label {
            display: block;
            font-size: 14px;
            color: var(--default-color);
            margin-bottom: 5px;
        }

        .input-group input {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 6px;
            font-size: 16px;
            transition: 0.3s ease;
            outline: none;
        }

        .input-group input:focus {
            border-color: var(--accent-color);
            box-shadow: 0 0 5px rgba(220, 195, 161, 0.5);
        }

        .register-btn, .return-btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 6px;
            font-size: 18px;
            cursor: pointer;
            transition: 0.3s;
            margin-top: 10px;
            font-family: var(--nav-font);
        }

        .register-btn {
            background: var(--accent-color);
            color: var(--contrast-color);
        }

        .register-btn:hover {
            background: #c3a37d;
        }

        .return-btn {
            background: #ccc;
            color: var(--default-color);
        }

        .return-btn:hover {
            background: #bbb;
        }

        .login-link {
            margin-top: 10px;
            font-size: 14px;
            color: var(--default-color);
        }

        .login-link a {
            color: var(--accent-color);
            text-decoration: none;
        }

        .login-link a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

    <div class="register-container">
    <?php
        include './database/connection.php';

        if (isset($_POST['register-btn'])) {
            $first_name = $_POST["first_name"];
            $last_name = $_POST["last_name"];
            $birthday = $_POST["birthday"];
            $address = $_POST["address"];
            $contact_no = $_POST["contact_no"];
            $email = $_POST["email"];
            $username = $_POST["username"];
            $password =$_POST["password"]; 

            $sql = "INSERT INTO `registration`(`first_name`, `last_name`, `birthday`, `address`, `contact_no`, `email`, `username`, `password`) 
                    VALUES ('$first_name','$last_name','$birthday','$address','$contact_no','$email','$username','$password')";

            if ($con->query($sql) === TRUE) {
                echo "<script>alert('Registration Successful! ');</script>";
                echo "<script>window.location.href='login.php';</script>"; 
            } else {
                echo "<script>alert('Registration Failed. Please try again.');</script>";
            }
        }
    ?>
        <h2>Register</h2>
        <form action="register.php" method="POST">
            <div class="input-group">
                <label for="first_name">First Name</label>
                <input type="text" id="first_name" name="first_name" required>
            </div>
            <div class="input-group">
                <label for="last_name">Last Name</label>
                <input type="text" id="last_name" name="last_name" required>
            </div>
            <div class="input-group">
                <label for="birthday">Birthday</label>
                <input type="date" id="birthday" name="birthday" required>
            </div>
            <div class="input-group">
                <label for="address">Address</label>
                <input type="text" id="address" name="address" required>
            </div>
            <div class="input-group">
                <label for="contact_no">Contact Number</label>
                <input type="tel" id="contact_no" name="contact_no" pattern="[0-9]{10,15}" placeholder="Enter your phone number" required>
            </div>
            <div class="input-group">
                <label for="email">Email</label>
                <input type="email" id="email" name="email" required>
            </div>
            <div class="input-group">
                <label for="username">Username</label>
                <input type="text" id="username" name="username" required>
            </div>
            <div class="input-group">
                <label for="password">Password</label>
                <input type="password" id="password" name="password" required>
            </div>
            <button type="submit" class="register-btn" name="register-btn">Register</button>
            <button type="button" class="return-btn" onclick="goBack()">Return</button>
        </form>
        <div class="login-link">
            Already have an account? <a href="login.php">Login</a>
        </div>
    </div>

    <script>
        function goBack() {
            window.history.back();
        }
    </script>

</body>
</html>
</style>