<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('../database/connection.php'); // Ensure this path is correct

// Function to log user activity
function log_user_activity($user_id, $activity) {
    global $con; // Use the global database connection
    $stmt = $con->prepare("INSERT INTO recent_activities (user_id, activity, activity_time) VALUES (?, ?, NOW())");
    $stmt->bind_param("is", $user_id, $activity);
    $stmt->execute();
    $stmt->close();
}

// Check if user is logged in and log activity
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    log_user_activity($user_id, "User logged in.");
}

// Get today's date in the format 'Y-m-d'
$today = date('Y-m-d');

// Count today's sales from both orders and ready_made_orders tables
$sql_sales_count = "SELECT 
                    (SELECT COUNT(*) FROM orders WHERE DATE(created_at) = '$today') +
                    (SELECT COUNT(*) FROM ready_made_orders WHERE DATE(order_date) = '$today') as total_sales";
$result_sales_count = $con->query($sql_sales_count);
$sales_today = $result_sales_count->fetch_assoc()['total_sales'];

// Calculate total revenue today
$sql_revenue_today = "SELECT 
                      (SELECT COALESCE(SUM(total_amount), 0) FROM orders WHERE DATE(created_at) = '$today') +
                      (SELECT COALESCE(SUM(total_amount), 0) FROM ready_made_orders WHERE DATE(order_date) = '$today') as total_revenue";
$result_revenue_today = $con->query($sql_revenue_today);
$revenue_today = $result_revenue_today->fetch_assoc()['total_revenue'];

// Count unique customers today (using email as identifier)
$sql_customers_today = "SELECT COUNT(DISTINCT customer_email) as total_customers FROM 
                       (SELECT customer_email FROM orders WHERE DATE(created_at) = '$today'
                        UNION 
                        SELECT customer_email FROM ready_made_orders WHERE DATE(order_date) = '$today') as combined_customers";
$result_customers_today = $con->query($sql_customers_today);
$customers_today = $result_customers_today->fetch_assoc()['total_customers'];

// Fetch recent activities
$sql_activities = "SELECT r.first_name, r.last_name, a.activity, a.activity_time 
                   FROM recent_activities a
                   JOIN registration r ON a.user_id = r.user_id
                   ORDER BY a.activity_time DESC LIMIT 5";
$result_activities = $con->query($sql_activities);

// Fetch recent sales
$sql_sales = "SELECT * FROM orders ORDER BY created_at DESC LIMIT 5";
$result_sales = $con->query($sql_sales);

// Fetch recent ready-made orders
$sql_ready_made = "SELECT *, 'pending' as status FROM ready_made_orders ORDER BY order_date DESC LIMIT 5";
$result_ready_made = $con->query($sql_ready_made);

// Fetch recent customizations
$sql_customizations = "SELECT * FROM customizations ORDER BY id DESC LIMIT 5";
$result_customizations = $con->query($sql_customizations);
?>

<div class="pagetitle">
  <h1>Dashboard</h1>
</div>
<section class="section dashboard">
  <div class="row">
    <!-- Left side columns -->
    <div class="col-lg-8">
      <div class="row">
        <!-- Sales Card -->
        <div class="col-xxl-4 col-md-6">
          <div class="card info-card sales-card">
            <div class="card-body">
              <h5 class="card-title">Sales <span>| Today</span></h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-cart"></i>
                </div>
                <div class="ps-3">
                  <h6><?php echo $sales_today; ?></h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                </div>
              </div>
            </div>
          </div>
        </div><!-- End Sales Card -->

        <!-- Revenue Card -->
        <div class="col-xxl-4 col-md-6">
          <div class="card info-card revenue-card">
            <div class="card-body">
              <h5 class="card-title">Revenue <span>| This Month</span></h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-currency-dollar"></i>
                </div>
                <div class="ps-3">
                  <h6>₱<?php echo number_format($revenue_today, 2); ?></h6>
                  <span class="text-success small pt-1 fw-bold">8%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                </div>
              </div>
            </div>
          </div>
        </div><!-- End Revenue Card -->

        <!-- Customers Card -->
        <div class="col-xxl-4 col-xl-12">
          <div class="card info-card customers-card">
            <div class="card-body">
              <h5 class="card-title">Customers <span>| Today</span></h5>
              <div class="d-flex align-items-center">
                <div class="card-icon rounded-circle d-flex align-items-center justify-content-center">
                  <i class="bi bi-people"></i>
                </div>
                <div class="ps-3">
                  <h6><?php echo $customers_today; ?></h6>
                  <span class="text-success small pt-1 fw-bold">12%</span> <span class="text-muted small pt-2 ps-1">increase</span>
                </div>
              </div>
            </div>
          </div>
        </div><!-- End Customers Card -->

        <!-- Reports -->

        <!-- Recent Sales -->
        <div class="col-12">
          <div class="card recent-sales">
            <div class="card-body">
              <h5 class="card-title">Recent Orders <span>| Today</span></h5>
              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Product</th>
                    <th scope="col">Price</th>
                    <th scope="col">Quantity</th>
                    <th scope="col">Total</th>
                    <th scope="col">Customer Email</th>
                    <th scope="col">Customer Address</th>
                    <th scope="col">Customer Phone</th>
                    <th scope="col">Status</th>
                    <th scope="col">Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = $result_sales->fetch_assoc()): ?>
                    <tr id="order-<?php echo $row['id']; ?>">
                      <th scope="row"><?php echo $row['id']; ?></th>
                      <td><?php echo htmlspecialchars($row['product_name']); ?></td>
                      <td>₱<?php echo htmlspecialchars($row['price']); ?></td>
                      <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                      <td>₱<?php echo htmlspecialchars($row['total_amount']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_email']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_address']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_phone']); ?></td>
                      <td><span class="badge bg-<?php echo $row['status'] == 'pending' ? 'warning' : ($row['status'] == 'completed' ? 'primary' : 'secondary'); ?>"><?php echo ucfirst($row['status']); ?></span></td>
                      <td class="action-buttons">
                        <form class="update-order-form" data-order-id="<?php echo $row['id']; ?>" style="display:inline;">
                          <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                          <input type="hidden" name="status" value="completed">
                          <button type="submit" class="btn btn-success btn-sm">Done</button>
                        </form>
                        <form class="delete-order-form" data-order-id="<?php echo $row['id']; ?>" style="display:inline;">
                          <input type="hidden" name="order_id" value="<?php echo $row['id']; ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                        </form>
                      </td>
                    </tr>
                  <?php endwhile; ?>
                  
                  <?php 
                  // Add ready-made orders to the table
                  while ($row = $result_ready_made->fetch_assoc()): 
                    // Get product name from products table
                    $product_id = $row['product_id'];
                    $product_query = "SELECT product_name FROM products WHERE product_id = '$product_id'";
                    $product_result = $con->query($product_query);
                    $product_name = ($product_result && $product_result->num_rows > 0) ? $product_result->fetch_assoc()['product_name'] : 'Unknown Product';
                  ?>
                    <tr id="ready-order-<?php echo $row['order_id']; ?>">
                      <th scope="row"><?php echo $row['order_id']; ?></th>
                      <td><?php echo htmlspecialchars($product_name); ?></td>
                      <td>₱<?php echo htmlspecialchars($row['total_amount'] / $row['quantity']); ?></td>
                      <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                      <td>₱<?php echo htmlspecialchars($row['total_amount']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_email']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_address']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_phone']); ?></td>
                      <td><span class="badge bg-warning">Pending</span></td>
                      <td class="action-buttons">
                        <form class="update-ready-order-form" data-order-id="<?php echo $row['order_id']; ?>" style="display:inline;">
                          <input type="hidden" name="ready_order_id" value="<?php echo $row['order_id']; ?>">
                          <input type="hidden" name="status" value="completed">
                          <button type="submit" class="btn btn-success btn-sm">Done</button>
                        </form>
                        <form class="delete-ready-order-form" data-order-id="<?php echo $row['order_id']; ?>" style="display:inline;">
                          <input type="hidden" name="ready_order_id" value="<?php echo $row['order_id']; ?>">
                          <button type="submit" class="btn btn-danger btn-sm">Cancel</button>
                        </form>
                      </td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div><!-- End Recent Sales -->

        <!-- Recent Customizations -->
        <div class="col-12">
          <div class="card recent-customizations">
            <div class="card-body">
              <h5 class="card-title">Recent Customizations <span>| Today</span></h5>
              <table class="table table-borderless datatable">
                <thead>
                  <tr>
                    <th scope="col">#</th>
                    <th scope="col">Customer Name</th>
                    <th scope="col">Email</th>
                    <th scope="col">Address</th>
                    <th scope="col">Phone</th>
                    <th scope="col">Dress Style</th>
                    <th scope="col">Fabric Type</th>
                    <th scope="col">Color</th>
                    <th scope="col">Neckline</th>
                    <th scope="col">Size</th>
                    <th scope="col">Quantity</th>
                  </tr>
                </thead>
                <tbody>
                  <?php while ($row = $result_customizations->fetch_assoc()): ?>
                    <tr id="customization-<?php echo $row['id']; ?>">
                      <th scope="row"><?php echo $row['id']; ?></th>
                      <td><?php echo htmlspecialchars($row['customer_name']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_email']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_address']); ?></td>
                      <td><?php echo htmlspecialchars($row['customer_phone']); ?></td>
                      <td><?php echo htmlspecialchars($row['dress_style']); ?></td>
                      <td><?php echo htmlspecialchars($row['fabric_type']); ?></td>
                      <td><?php echo htmlspecialchars($row['color']); ?></td>
                      <td><?php echo htmlspecialchars($row['neckline']); ?></td>
                      <td><?php echo htmlspecialchars($row['size']); ?></td>
                      <td><?php echo htmlspecialchars($row['quantity']); ?></td>
                    </tr>
                  <?php endwhile; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div><!-- End Recent Customizations -->
      </div>
    </div><!-- End Left side columns -->

    <!-- Right side columns -->
    <div class="col-lg-4">
      <!-- Recent Activity -->
      <div class="card">
        <div class="card-body">
          <h5 class="card-title">Recent Activity <span>| Today</span></h5>
          <div class="activity">
            <?php while ($row = $result_activities->fetch_assoc()): ?>
              <div class="activity-item d-flex">
                <div class="activite-label"><?php echo time_elapsed_string($row['activity_time']); ?></div>
                <i class='bi bi-circle-fill activity-badge text-success align-self-start'></i>
                <div class="activity-content">
                  <?php echo htmlspecialchars($row['first_name'] . ' ' . $row['last_name'] . ' - ' . $row['activity']); ?>
                </div>
              </div>
            <?php endwhile; ?>
          </div>
        </div>
      </div><!-- End Recent Activity -->
    </div><!-- End Right side columns -->
  </div>
</section>

<?php
// Function to calculate time elapsed
function time_elapsed_string($datetime, $full = false) {
    $now = new DateTime;
    $ago = new DateTime($datetime);
    $diff = $now->diff($ago);

    // Calculate weeks only if there are enough days
    $weeks = floor($diff->d / 7);
    $diff->d -= $weeks * 7;

    $string = array(
        'y' => 'year',
        'm' => 'month',
        'd' => 'day',
        'h' => 'hour',
        'i' => 'minute',
        's' => 'second',
    );

    // Add weeks to the string if applicable
    if ($weeks > 0) {
        $string['w'] = $weeks . ' week' . ($weeks > 1 ? 's' : '');
    }

    foreach ($string as $k => &$v) {
        if ($diff->$k) {
            $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
        } else {
            unset($string[$k]);
        }
    }

    if (!$full) $string = array_slice($string, 0, 1);
    return $string ? implode(', ', $string) . ' ago' : 'just now';
}
?>

<style>
  .action-buttons {
    white-space: nowrap;
  }
  .action-buttons form {
    display: inline-block;
    margin-right: 5px;
  }
  .action-buttons .btn {
    margin-bottom: 5px;
  }

  /* Add margins to dashboard elements */
  .pagetitle {
    margin-bottom: 25px;
    padding: 10px 0;
  }

  .dashboard .card {
    margin-bottom: 25px;
    transition: all 0.3s ease;
    border: none;
    border-radius: 12px;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    overflow: hidden;
  }

  .dashboard .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 2rem 0 rgba(58, 59, 69, 0.2);
  }

  /* Individual card hover effects */
  .sales-card:hover .card-icon {
    background: linear-gradient(45deg, #4e73df, #36b9cc);
    transform: scale(1.1) rotate(10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .revenue-card:hover .card-icon {
    background: linear-gradient(45deg, #1cc88a, #4e73df);
    transform: scale(1.1) rotate(-10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .customers-card:hover .card-icon {
    background: linear-gradient(45deg, #f6c23e, #e74a3b);
    transform: scale(1.1) rotate(10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .card-icon {
    transition: all 0.3s ease;
    width: 50px;
    height: 50px;
    font-size: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  }

  .sales-card .card-icon {
    background: #4e73df;
  }

  .revenue-card .card-icon {
    background: #1cc88a;
  }

  .customers-card .card-icon {
    background: #f6c23e;
  }

  /* Table row animations */
  .table tbody tr {
    transition: all 0.2s ease;
  }

  .table tbody tr:hover {
    background-color: rgba(78, 115, 223, 0.05);
    transform: translateX(5px);
    box-shadow: -5px 0 0 #4e73df;
  }

  /* Button animations */
  .btn {
    transition: all 0.2s ease;
  }

  .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  }

  /* Activity item animations */
  .activity-item {
    transition: all 0.3s ease;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  }

  .activity-item:hover {
    transform: translateX(5px);
    background-color: rgba(78, 115, 223, 0.05);
    border-radius: 8px;
    padding-left: 10px;
  }

  .activity-item:hover .activity-badge {
    transform: scale(1.2);
  }

  .activity-badge {
    transition: all 0.3s ease;
  }

  .col-xxl-4, .col-md-6, .col-xl-12 {
    margin-bottom: 20px;
  }

  .card-body {
    padding: 20px;
  }

  .dashboard .info-card {
    margin-bottom: 30px;
  }

  .recent-sales, .recent-customizations {
    margin-bottom: 30px;
  }

  .table {
    margin-top: 15px;
  }

  .dashboard .row {
    margin-bottom: 20px;
  }

  .card-title {
    padding-bottom: 15px;
    margin-bottom: 20px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  }

  .activity-item:last-child {
    border-bottom: none;
  }

  /* Enhanced sidebar styling */
  .sidebar {
    background: #fff;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
    transition: all 0.3s ease-in-out;
    padding-top: 35px;
    border-right: 1px solid rgba(0, 0, 0, 0.05);
  }

  .sidebar-nav {
    padding: 15px 10px;
  }

  .sidebar-nav .nav-item {
    margin-bottom: 20px;
  }

  .sidebar-nav .nav-link {
    color: #baaa8b;
    padding: 15px 25px;
    border-radius: 8px;
    margin: 0 5px;
    transition: all 0.3s;
    font-size: 1.2rem;
    font-weight: 500;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
  }

  .sidebar-nav .nav-link:hover {
    color: #795c34;
    background-color: rgba(186, 170, 139, 0.08);
    transform: translateX(7px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  }

  .sidebar-nav .nav-link.active {
    color: #795c34;
    font-weight: 600;
    background-color: rgba(186, 170, 139, 0.15);
  }

  .sidebar-nav .nav-link i {
    font-size: 1.3rem;
    margin-right: 18px;
    width: 28px;
    text-align: center;
    color: #baaa8b;
    transition: all 0.3s;
  }

  .sidebar-nav .nav-link.active i,
  .sidebar-nav .nav-link:hover i {
    color: #795c34;
    transform: scale(1.15);
  }

  .sidebar-nav .nav-content {
    padding-left: 45px;
  }

  .sidebar-nav .nav-content a {
    display: flex;
    align-items: center;
    font-size: 1.05rem;
    font-weight: 400;
    color: #baaa8b;
    padding: 12px 5px;
    margin: 6px 0;
    border-radius: 5px;
    transition: all 0.3s;
  }

  .sidebar-nav .nav-content a:hover,
  .sidebar-nav .nav-content a.active {
    color: #795c34;
    background-color: rgba(186, 170, 139, 0.08);
    padding-left: 10px;
  }

  .sidebar-nav .nav-content a i {
    font-size: 0.95rem;
    margin-right: 12px;
    color: #baaa8b;
  }

  .sidebar-nav .nav-content a:hover i,
  .sidebar-nav .nav-content a.active i {
    color: #795c34;
  }

  /* Sidebar header styling */
  .sidebar-header {
    padding: 0 20px 30px 20px;
    text-align: center;
  }

  .sidebar-header h2 {
    color: #795c34;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 5px;
  }

  .sidebar-header p {
    color: #baaa8b;
    font-size: 0.9rem;
  }

  /* Main content padding when sidebar is present */
  .main-content {
    padding-left: 25px;
  }
</style>

<script>
  document.addEventListener('DOMContentLoaded', function() {
    // Handle update order form submission
    document.querySelectorAll('.update-order-form').forEach(function(form) {
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        var orderId = form.getAttribute('data-order-id');
        var formData = new FormData(form);

        fetch('update_order.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.status === 'success') {
            document.querySelector('#order-' + orderId + ' .badge').classList.remove('bg-warning');
            document.querySelector('#order-' + orderId + ' .badge').classList.add('bg-primary');
            document.querySelector('#order-' + orderId + ' .badge').textContent = 'Completed';
          } else {
            alert('Failed to update order status. Please try again.');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Failed to update order status. Please try again.');
        });
      });
    });

    // Handle delete order form submission
    document.querySelectorAll('.delete-order-form').forEach(function(form) {
      form.addEventListener('submit', function(event) {
        event.preventDefault();
        var orderId = form.getAttribute('data-order-id');
        var formData = new FormData(form);

        fetch('delete_order.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.status === 'success') {
            document.querySelector('#order-' + orderId).remove();
          } else {
            alert('Failed to delete order. Please try again.');
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('Failed to delete order. Please try again.');
        });
      });
    });

    // Handle update ready-made order form submissions
    document.querySelectorAll('.update-ready-order-form').forEach(form => {
      form.addEventListener('submit', function(e) {
        e.preventDefault();

        const orderID = this.dataset.orderId;
        const formData = new FormData(this);
        formData.append('action', 'update');

        fetch('process_ready_made_orders.php', {
          method: 'POST',
          body: formData
        })
        .then(response => response.json())
        .then(data => {
          if (data.status === 'success') {
            alert('Order status updated successfully!');

            // Update status badge
            const statusBadge = document.querySelector(`#ready-order-${orderID} td:nth-child(9) span`);
            statusBadge.classList.remove('bg-warning');
            statusBadge.classList.add('bg-primary');
            statusBadge.textContent = 'Completed';
          } else {
            alert('Failed to update order status: ' + data.message);
          }
        })
        .catch(error => {
          console.error('Error:', error);
          alert('An error occurred while updating the order.');
        });
      });
    });

    // Handle delete ready-made order form submissions
    document.querySelectorAll('.delete-ready-order-form').forEach(form => {
      form.addEventListener('submit', function(e) {
        e.preventDefault();

        if (confirm('Are you sure you want to cancel this order?')) {
          const orderID = this.dataset.orderId;
          const formData = new FormData(this);
          formData.append('action', 'delete');

          fetch('process_ready_made_orders.php', {
            method: 'POST',
            body: formData
          })
          .then(response => response.json())
          .then(data => {
            if (data.status === 'success') {
              alert('Order cancelled successfully!');

              // Remove the row from the table
              document.querySelector(`#ready-order-${orderID}`).remove();
            } else {
              alert('Failed to cancel order: ' + data.message);
            }
          })
          .catch(error => {
            console.error('Error:', error);
            alert('An error occurred while cancelling the order.');
          });
        }
      });
    });
  });
</script>