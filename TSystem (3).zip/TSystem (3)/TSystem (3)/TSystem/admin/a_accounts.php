<?php 
include '../database/connection.php';

$sql = "SELECT `user_id`, `first_name`, `last_name`, `birthday`, `address`, `contact_no`, `email`, `username` 
        FROM `registration` 
        WHERE `deleted_at` IS NULL";
$result = $con->query($sql);
?>

<div class="pagetitle">
  <h1>Manage Accounts</h1>
</div>
<table class="table datatable">
    <thead>
        <tr>
            <th>ID</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Birthday</th>
            <th>Address</th>
            <th>Contact Number</th>
            <th>Email</th>
            <th>Username</th>
            <th>Action</th>
        </tr>  
    </thead>
    <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
        <tr> 
            <td><?php echo $row['user_id']; ?></td>
            <td><?php echo $row['first_name']; ?></td>
            <td><?php echo $row['last_name']; ?></td>
            <td><?php echo $row['birthday']; ?></td>
            <td><?php echo $row['address']; ?></td>
            <td><?php echo $row['contact_no']; ?></td>
            <td><?php echo $row['email']; ?></td>
            <td><?php echo $row['username']; ?></td>
            <td>
                <a href="/TSystem/delete.php?id=<?php echo $row['user_id']; ?>" class="btn btn-danger">
                    <i class="bi bi-trash"></i> Delete
                </a>
            </td>
        </tr>
        <?php endwhile; ?>
    </tbody>
</table>
<style>
  .action-buttons {
    white-space: nowrap;
  }
  .action-buttons form {
    display: inline-block;
    margin-right: 5px;
  }
  .action-buttons .btn {
    margin-bottom: 5px;
  }

  /* Add margins to dashboard elements */
  .pagetitle {
    margin-bottom: 25px;
    padding: 10px 0;
  }

  .dashboard .card {
    margin-bottom: 25px;
    transition: all 0.3s ease;
    border: none;
    border-radius: 12px;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    overflow: hidden;
  }

  .dashboard .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 2rem 0 rgba(58, 59, 69, 0.2);
  }

  /* Individual card hover effects */
  .sales-card:hover .card-icon {
    background: linear-gradient(45deg, #4e73df, #36b9cc);
    transform: scale(1.1) rotate(10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .revenue-card:hover .card-icon {
    background: linear-gradient(45deg, #1cc88a, #4e73df);
    transform: scale(1.1) rotate(-10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .customers-card:hover .card-icon {
    background: linear-gradient(45deg, #f6c23e, #e74a3b);
    transform: scale(1.1) rotate(10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .card-icon {
    transition: all 0.3s ease;
    width: 50px;
    height: 50px;
    font-size: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  }

  .sales-card .card-icon {
    background: #4e73df;
  }

  .revenue-card .card-icon {
    background: #1cc88a;
  }

  .customers-card .card-icon {
    background: #f6c23e;
  }

  /* Table row animations */
  .table tbody tr {
    transition: all 0.2s ease;
  }

  .table tbody tr:hover {
    background-color: rgba(78, 115, 223, 0.05);
    transform: translateX(5px);
    box-shadow: -5px 0 0 #4e73df;
  }

  /* Button animations */
  .btn {
    transition: all 0.2s ease;
  }

  .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  }

  /* Activity item animations */
  .activity-item {
    transition: all 0.3s ease;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  }

  .activity-item:hover {
    transform: translateX(5px);
    background-color: rgba(78, 115, 223, 0.05);
    border-radius: 8px;
    padding-left: 10px;
  }

  .activity-item:hover .activity-badge {
    transform: scale(1.2);
  }

  .activity-badge {
    transition: all 0.3s ease;
  }

  .col-xxl-4, .col-md-6, .col-xl-12 {
    margin-bottom: 20px;
  }

  .card-body {
    padding: 20px;
  }

  .dashboard .info-card {
    margin-bottom: 30px;
  }

  .recent-sales, .recent-customizations {
    margin-bottom: 30px;
  }

  .table {
    margin-top: 15px;
  }

  .dashboard .row {
    margin-bottom: 20px;
  }

  .card-title {
    padding-bottom: 15px;
    margin-bottom: 20px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  }

  .activity-item:last-child {
    border-bottom: none;
  }

  /* Enhanced sidebar styling */
  .sidebar {
    background: #fff;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
    transition: all 0.3s ease-in-out;
    padding-top: 35px;
    border-right: 1px solid rgba(0, 0, 0, 0.05);
  }

  .sidebar-nav {
    padding: 15px 10px;
  }

  .sidebar-nav .nav-item {
    margin-bottom: 20px;
  }

  .sidebar-nav .nav-link {
    color: #baaa8b;
    padding: 15px 25px;
    border-radius: 8px;
    margin: 0 5px;
    transition: all 0.3s;
    font-size: 1.2rem;
    font-weight: 500;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
  }

  .sidebar-nav .nav-link:hover {
    color: #795c34;
    background-color: rgba(186, 170, 139, 0.08);
    transform: translateX(7px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  }

  .sidebar-nav .nav-link.active {
    color: #795c34;
    font-weight: 600;
    background-color: rgba(186, 170, 139, 0.15);
  }

  .sidebar-nav .nav-link i {
    font-size: 1.3rem;
    margin-right: 18px;
    width: 28px;
    text-align: center;
    color: #baaa8b;
    transition: all 0.3s;
  }

  .sidebar-nav .nav-link.active i,
  .sidebar-nav .nav-link:hover i {
    color: #795c34;
    transform: scale(1.15);
  }

  .sidebar-nav .nav-content {
    padding-left: 45px;
  }

  .sidebar-nav .nav-content a {
    display: flex;
    align-items: center;
    font-size: 1.05rem;
    font-weight: 400;
    color: #baaa8b;
    padding: 12px 5px;
    margin: 6px 0;
    border-radius: 5px;
    transition: all 0.3s;
  }

  .sidebar-nav .nav-content a:hover,
  .sidebar-nav .nav-content a.active {
    color: #795c34;
    background-color: rgba(186, 170, 139, 0.08);
    padding-left: 10px;
  }

  .sidebar-nav .nav-content a i {
    font-size: 0.95rem;
    margin-right: 12px;
    color: #baaa8b;
  }

  .sidebar-nav .nav-content a:hover i,
  .sidebar-nav .nav-content a.active i {
    color: #795c34;
  }

  /* Sidebar header styling */
  .sidebar-header {
    padding: 0 20px 30px 20px;
    text-align: center;
  }

  .sidebar-header h2 {
    color: #795c34;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 5px;
  }

  .sidebar-header p {
    color: #baaa8b;
    font-size: 0.9rem;
  }

  /* Main content padding when sidebar is present */
  .main-content {
    padding-left: 25px;
  }
</style>