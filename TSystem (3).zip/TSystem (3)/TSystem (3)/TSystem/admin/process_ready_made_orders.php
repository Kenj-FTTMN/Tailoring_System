<?php
session_start();
include('../database/connection.php');

// Set content type header for JSON response
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Update order status
    if (isset($_POST['action']) && $_POST['action'] === 'update' && isset($_POST['ready_order_id'])) {
        $order_id = mysqli_real_escape_string($con, $_POST['ready_order_id']);
        $status = mysqli_real_escape_string($con, $_POST['status']);
        
        // Check if the status column exists in the ready_made_orders table
        $table_check = mysqli_query($con, "SHOW COLUMNS FROM ready_made_orders LIKE 'status'");
        
        if (mysqli_num_rows($table_check) == 0) {
            // Add status column if it doesn't exist
            $alter_table = "ALTER TABLE ready_made_orders ADD COLUMN status VARCHAR(20) DEFAULT 'pending'";
            mysqli_query($con, $alter_table);
        }
        
        // Update the order status
        $update_query = "UPDATE ready_made_orders SET status = '$status' WHERE order_id = '$order_id'";
        
        if (mysqli_query($con, $update_query)) {
            echo json_encode(['status' => 'success', 'message' => 'Order status updated successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to update order status: ' . mysqli_error($con)]);
        }
    }
    // Delete order
    else if (isset($_POST['action']) && $_POST['action'] === 'delete' && isset($_POST['ready_order_id'])) {
        $order_id = mysqli_real_escape_string($con, $_POST['ready_order_id']);
        
        // Delete the order
        $delete_query = "DELETE FROM ready_made_orders WHERE order_id = '$order_id'";
        
        if (mysqli_query($con, $delete_query)) {
            echo json_encode(['status' => 'success', 'message' => 'Order deleted successfully']);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Failed to delete order: ' . mysqli_error($con)]);
        }
    }
    else {
        echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
} 