<div class="pagetitle">
    <h1>Messages</h1>
</div>
<?php 
// Use a relative path from the current directory
require_once('../database/connection.php');

// Fetch messages with error handling
try {
    $sql = "SELECT `user_id`, `name`, `email`, `message` FROM `message` ORDER BY `user_id` DESC";
    $result = mysqli_query($con, $sql);

    if (!$result) {
        throw new Exception("Query failed: " . mysqli_error($con));
    }
?>
<section class="section">
    <div class="row">
        <div class="col-lg-8">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Inbox <span>| Customer Messages</span></h5>
                    
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <div class="messages-container">
                            <?php while ($row = mysqli_fetch_assoc($result)):
                                // Since created_at doesn't exist, we'll use current date as fallback
                            ?>
                                <div class="message-card">
                                    <div class="message-header">
                                        <div class="sender-info">
                                            <div class="avatar">
                                                <span><?php echo substr(htmlspecialchars($row['name']), 0, 1); ?></span>
                                            </div>
                                            <div class="details">
                                                <h4><?php echo htmlspecialchars($row['name']); ?></h4>
                                                <a href="mailto:<?php echo htmlspecialchars($row['email']); ?>"><?php echo htmlspecialchars($row['email']); ?></a>
                                            </div>
                                        </div>
                                        <div class="message-date">
                                            <i class="bi bi-chat-fill"></i> Message #<?php echo $row['user_id']; ?>
                                        </div>
                                    </div>
                                    <div class="message-content">
                                        <p><?php echo nl2br(htmlspecialchars($row['message'])); ?></p>
                                    </div>
                                    <div class="message-actions">
                                        <form method="post" class="d-inline delete-message-form">
                                            <input type="hidden" name="message_id" value="<?php echo $row['user_id']; ?>">
                                            <button type="submit" class="btn btn-danger btn-sm"><i class="bi bi-trash"></i> Delete</button>
                                        </form>
                                    </div>
                                </div>
                            <?php endwhile; ?>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info">
                            <i class="bi bi-info-circle me-2"></i> No messages found in your inbox.
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Right side columns - Recent Activity -->
        <div class="col-lg-4">
            <div class="card">
                <div class="card-body">
                    <h5 class="card-title">Recent Activity <span>| Today</span></h5>
                    
                    <div class="activity">
                        <?php
                        // Fetch recent activities
                        $sql_activities = "SELECT r.first_name, r.last_name, a.activity, a.activity_time 
                                          FROM recent_activities a
                                          JOIN registration r ON a.user_id = r.user_id
                                          ORDER BY a.activity_time DESC LIMIT 10";
                        $result_activities = $con->query($sql_activities);
                        
                        if ($result_activities && $result_activities->num_rows > 0) {
                            while ($activity = $result_activities->fetch_assoc()) {
                                // Calculate time elapsed
                                $activity_time = strtotime($activity['activity_time']);
                                $current_time = time();
                                $time_diff = $current_time - $activity_time;
                                
                                if ($time_diff < 60) {
                                    $time_display = "just now";
                                } elseif ($time_diff < 3600) {
                                    $mins = floor($time_diff / 60);
                                    $time_display = $mins . " minute" . ($mins > 1 ? "s" : "") . " ago";
                                } elseif ($time_diff < 86400) {
                                    $hours = floor($time_diff / 3600);
                                    $time_display = $hours . " hour" . ($hours > 1 ? "s" : "") . " ago";
                                } else {
                                    $time_display = date("M j", $activity_time);
                                }
                                
                                $user_name = $activity['first_name'] . ' ' . $activity['last_name'];
                        ?>
                        <div class="activity-item d-flex">
                            <div class="activite-label"><?php echo $time_display; ?></div>
                            <i class='bi bi-circle-fill activity-badge text-success align-self-start'></i>
                            <div class="activity-content">
                                <?php echo htmlspecialchars($user_name) . ' - ' . htmlspecialchars($activity['activity']); ?>
                            </div>
                        </div>
                        <?php
                            }
                        } else {
                            echo '<div class="text-center text-muted">No recent activities found.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php
} catch (Exception $e) {
    echo '<div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i> Error: ' . $e->getMessage() . '</div>';
}

// Delete message functionality
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message_id'])) {
    $message_id = mysqli_real_escape_string($con, $_POST['message_id']);
    $delete_sql = "DELETE FROM `message` WHERE `user_id` = '$message_id'";
    
    if (mysqli_query($con, $delete_sql)) {
        echo '<script>
            document.addEventListener("DOMContentLoaded", function() {
                alert("Message deleted successfully!");
                window.location.reload();
            });
        </script>';
    } else {
        echo '<div class="alert alert-danger"><i class="bi bi-exclamation-triangle me-2"></i> Error deleting message: ' . mysqli_error($con) . '</div>';
    }
}

// Close the connection
mysqli_close($con);
?>

<style>
  /* Message specific styling */
  .messages-container {
    display: flex;
    flex-direction: column;
    gap: 20px;
  }
  
  .message-card {
    background-color: #fff;
    border-radius: 12px;
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
    overflow: hidden;
    transition: all 0.3s ease;
    border-left: 5px solid #baaa8b;
  }
  
  .message-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 8px 24px rgba(0, 0, 0, 0.1);
  }
  
  .message-header {
    padding: 20px;
    background-color: #f9f8f6;
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  }
  
  .sender-info {
    display: flex;
    align-items: center;
    gap: 15px;
  }
  
  .avatar {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #795c34;
    color: white;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 18px;
    font-weight: bold;
  }
  
  .details h4 {
    margin: 0;
    font-size: 16px;
    color: #333;
  }
  
  .details a {
    color: #795c34;
    text-decoration: none;
    font-size: 14px;
  }
  
  .details a:hover {
    text-decoration: underline;
  }
  
  .message-date {
    color: #888;
    font-size: 14px;
  }
  
  .message-content {
    padding: 20px;
    color: #444;
    font-size: 15px;
    background-color: white;
    line-height: 1.6;
  }
  
  .message-content p {
    margin-bottom: 0;
    white-space: pre-wrap;
  }
  
  .message-actions {
    padding: 15px 20px;
    background-color: #f9f8f6;
    display: flex;
    gap: 10px;
    border-top: 1px solid rgba(0, 0, 0, 0.05);
  }
  
  .message-actions .btn-primary {
    background-color: #795c34;
    border-color: #795c34;
  }
  
  .message-actions .btn-primary:hover {
    background-color: #68502d;
    border-color: #68502d;
  }
  
  /* Responsive adjustments */
  @media (max-width: 768px) {
    .message-header {
      flex-direction: column;
      align-items: flex-start;
    }
    
    .message-date {
      margin-top: 10px;
      align-self: flex-end;
    }
  }
  /* Add margins to dashboard elements */
  .pagetitle {
    margin-bottom: 25px;
    padding: 10px 0;
  }

  .dashboard .card {
    margin-bottom: 25px;
    transition: all 0.3s ease;
    border: none;
    border-radius: 12px;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.15);
    overflow: hidden;
  }

  .dashboard .card:hover {
    transform: translateY(-5px);
    box-shadow: 0 0.5rem 2rem 0 rgba(58, 59, 69, 0.2);
  }

  /* Individual card hover effects */
  .sales-card:hover .card-icon {
    background: linear-gradient(45deg, #4e73df, #36b9cc);
    transform: scale(1.1) rotate(10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .revenue-card:hover .card-icon {
    background: linear-gradient(45deg, #1cc88a, #4e73df);
    transform: scale(1.1) rotate(-10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .customers-card:hover .card-icon {
    background: linear-gradient(45deg, #f6c23e, #e74a3b);
    transform: scale(1.1) rotate(10deg);
    box-shadow: 0 10px 20px rgba(0, 0, 0, 0.15);
  }

  .card-icon {
    transition: all 0.3s ease;
    width: 50px;
    height: 50px;
    font-size: 24px;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
  }

  .sales-card .card-icon {
    background: #4e73df;
  }

  .revenue-card .card-icon {
    background: #1cc88a;
  }

  .customers-card .card-icon {
    background: #f6c23e;
  }

  /* Table row animations */
  .table tbody tr {
    transition: all 0.2s ease;
  }

  .table tbody tr:hover {
    background-color: rgba(78, 115, 223, 0.05);
    transform: translateX(5px);
    box-shadow: -5px 0 0 #4e73df;
  }

  /* Button animations */
  .btn {
    transition: all 0.2s ease;
  }

  .btn:hover {
    transform: translateY(-2px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
  }

  /* Activity item animations */
  .activity-item {
    transition: all 0.3s ease;
    margin-bottom: 15px;
    padding-bottom: 15px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  }

  .activity-item:hover {
    transform: translateX(5px);
    background-color: rgba(78, 115, 223, 0.05);
    border-radius: 8px;
    padding-left: 10px;
  }

  .activity-item:hover .activity-badge {
    transform: scale(1.2);
  }

  .activity-badge {
    transition: all 0.3s ease;
  }

  .col-xxl-4, .col-md-6, .col-xl-12 {
    margin-bottom: 20px;
  }

  .card-body {
    padding: 20px;
  }

  .dashboard .info-card {
    margin-bottom: 30px;
  }

  .recent-sales, .recent-customizations {
    margin-bottom: 30px;
  }

  .table {
    margin-top: 15px;
  }

  .dashboard .row {
    margin-bottom: 20px;
  }

  .card-title {
    padding-bottom: 15px;
    margin-bottom: 20px;
    border-bottom: 1px solid rgba(0, 0, 0, 0.05);
  }

  .activity-item:last-child {
    border-bottom: none;
  }

  /* Enhanced sidebar styling */
  .sidebar {
    background: #fff;
    box-shadow: 0 0.15rem 1.75rem 0 rgba(58, 59, 69, 0.1);
    transition: all 0.3s ease-in-out;
    padding-top: 35px;
    border-right: 1px solid rgba(0, 0, 0, 0.05);
  }

  .sidebar-nav {
    padding: 15px 10px;
  }

  .sidebar-nav .nav-item {
    margin-bottom: 20px;
  }

  .sidebar-nav .nav-link {
    color: #baaa8b;
    padding: 15px 25px;
    border-radius: 8px;
    margin: 0 5px;
    transition: all 0.3s;
    font-size: 1.2rem;
    font-weight: 500;
    letter-spacing: 0.5px;
    display: flex;
    align-items: center;
  }

  .sidebar-nav .nav-link:hover {
    color: #795c34;
    background-color: rgba(186, 170, 139, 0.08);
    transform: translateX(7px);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
  }

  .sidebar-nav .nav-link.active {
    color: #795c34;
    font-weight: 600;
    background-color: rgba(186, 170, 139, 0.15);
  }

  .sidebar-nav .nav-link i {
    font-size: 1.3rem;
    margin-right: 18px;
    width: 28px;
    text-align: center;
    color: #baaa8b;
    transition: all 0.3s;
  }

  .sidebar-nav .nav-link.active i,
  .sidebar-nav .nav-link:hover i {
    color: #795c34;
    transform: scale(1.15);
  }

  .sidebar-nav .nav-content {
    padding-left: 45px;
  }

  .sidebar-nav .nav-content a {
    display: flex;
    align-items: center;
    font-size: 1.05rem;
    font-weight: 400;
    color: #baaa8b;
    padding: 12px 5px;
    margin: 6px 0;
    border-radius: 5px;
    transition: all 0.3s;
  }

  .sidebar-nav .nav-content a:hover,
  .sidebar-nav .nav-content a.active {
    color: #795c34;
    background-color: rgba(186, 170, 139, 0.08);
    padding-left: 10px;
  }

  .sidebar-nav .nav-content a i {
    font-size: 0.95rem;
    margin-right: 12px;
    color: #baaa8b;
  }

  .sidebar-nav .nav-content a:hover i,
  .sidebar-nav .nav-content a.active i {
    color: #795c34;
  }

  /* Sidebar header styling */
  .sidebar-header {
    padding: 0 20px 30px 20px;
    text-align: center;
  }

  .sidebar-header h2 {
    color: #795c34;
    font-size: 1.5rem;
    font-weight: 700;
    margin-bottom: 5px;
  }

  .sidebar-header p {
    color: #baaa8b;
    font-size: 0.9rem;
  }

  /* Activity styling similar to the image */
  .activity {
    padding: 0;
  }
  
  .activity-item {
    position: relative;
    padding-bottom: 20px;
    padding-left: 20px;
    border-left: 2px solid #eee;
    margin-left: 20px;
  }
  
  .activity-item:last-child {
    padding-bottom: 0;
  }
  
  .activite-label {
    color: #888;
    font-size: 13px;
    margin-right: 15px;
    min-width: 85px;
    font-style: italic;
  }
  
  .activity-badge {
    position: absolute;
    left: -11px;
    top: 0;
    z-index: 1;
    font-size: 16px;
  }
  
  .activity-content {
    color: #444;
    font-size: 14px;
    padding-top: 0;
  }
  
  .activity-item:hover .activity-badge {
    transform: scale(1.2);
  }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Handle message deletion with confirmation
    document.querySelectorAll('.delete-message-form').forEach(form => {
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this message?')) {
                this.submit();
            }
        });
    });
});
</script>