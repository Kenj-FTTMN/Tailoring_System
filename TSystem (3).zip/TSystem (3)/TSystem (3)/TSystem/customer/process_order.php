<?php
session_start(); // Start the session
include('../database/connection.php'); // Ensure this path is correct

// Log the POST data for debugging
error_log('POST data: ' . print_r($_POST, true));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if all required fields are set for ready-made orders
    if (isset($_POST['product_id'], $_POST['customer_name'], $_POST['customer_email'], $_POST['customer_address'], $_POST['customer_phone'], $_POST['order_quantity'], $_POST['total_amount'])) {
        // Ready-made order
        $product_id = mysqli_real_escape_string($conn, $_POST['product_id']);
        $customer_name = mysqli_real_escape_string($conn, $_POST['customer_name']);
        $customer_email = mysqli_real_escape_string($conn, $_POST['customer_email']);
        $customer_address = mysqli_real_escape_string($conn, $_POST['customer_address']);
        $customer_phone = mysqli_real_escape_string($conn, $_POST['customer_phone']);
        $quantity = mysqli_real_escape_string($conn, $_POST['order_quantity']);
        $total_amount = mysqli_real_escape_string($conn, $_POST['total_amount']);

        error_log("Processing ready-made order: Product ID: $product_id, Customer: $customer_name, Quantity: $quantity");

        // Check if the ready_made_orders table exists
        $table_check = mysqli_query($conn, "SHOW TABLES LIKE 'ready_made_orders'");
        if (mysqli_num_rows($table_check) == 0) {
            // Create the table if it doesn't exist
            $create_table = "CREATE TABLE ready_made_orders (
                order_id INT AUTO_INCREMENT PRIMARY KEY,
                product_id INT NOT NULL,
                customer_name VARCHAR(255) NOT NULL,
                customer_email VARCHAR(255) NOT NULL,
                customer_address TEXT NOT NULL,
                customer_phone VARCHAR(20) NOT NULL,
                quantity INT NOT NULL,
                total_amount DECIMAL(10, 2) NOT NULL,
                order_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )";
            
            if (!mysqli_query($conn, $create_table)) {
                error_log("Error creating table: " . mysqli_error($conn));
                echo json_encode(['status' => 'error', 'message' => 'Could not create table: ' . mysqli_error($conn)]);
                exit();
            }
        }

        $order_query = "INSERT INTO ready_made_orders (product_id, customer_name, customer_email, customer_address, customer_phone, quantity, total_amount) 
                        VALUES (?, ?, ?, ?, ?, ?, ?)";
        $order_stmt = mysqli_prepare($conn, $order_query);
        
        if (!$order_stmt) {
            error_log("Prepare failed: " . mysqli_error($conn));
            echo json_encode(['status' => 'error', 'message' => 'Prepare failed: ' . mysqli_error($conn)]);
            exit();
        }
        
        mysqli_stmt_bind_param($order_stmt, "issssid", $product_id, $customer_name, $customer_email, $customer_address, $customer_phone, $quantity, $total_amount);

        if (mysqli_stmt_execute($order_stmt)) {
            $_SESSION['order_message'] = 'Order added successfully!';
            error_log("Order successfully added to database");
            echo json_encode(['status' => 'success', 'message' => 'Order added successfully!']);
            exit();
        } else {
            error_log('Order insert error: ' . mysqli_error($conn) . ' - Query: ' . $order_query);
            echo json_encode(['status' => 'error', 'message' => 'Order insert error: ' . mysqli_error($conn)]);
            exit();
        }

        mysqli_stmt_close($order_stmt);
    } 
    // Check if all required fields are set for customizations
    elseif (isset($_POST['customer_name'], $_POST['customer_email'], $_POST['customer_address'], $_POST['customer_phone'], $_POST['dressStyle'], $_POST['fabricType'], $_POST['color'], $_POST['neckline'], $_POST['size'], $_POST['order_quantity'])) {
        // Customization order
        $customer_name = mysqli_real_escape_string($conn, $_POST['customer_name']);
        $customer_email = mysqli_real_escape_string($conn, $_POST['customer_email']);
        $customer_address = mysqli_real_escape_string($conn, $_POST['customer_address']);
        $customer_phone = mysqli_real_escape_string($conn, $_POST['customer_phone']);
        $dress_style = mysqli_real_escape_string($conn, $_POST['dressStyle']);
        $fabric_type = mysqli_real_escape_string($conn, $_POST['fabricType']);
        $color = mysqli_real_escape_string($conn, $_POST['color']);
        $neckline = mysqli_real_escape_string($conn, $_POST['neckline']);
        $size = mysqli_real_escape_string($conn, $_POST['size']);
        $quantity = mysqli_real_escape_string($conn, $_POST['order_quantity']);

        $customization_query = "INSERT INTO customizations (customer_name, customer_email, customer_address, customer_phone, dress_style, fabric_type, color, neckline, size, quantity) 
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $customization_stmt = mysqli_prepare($conn, $customization_query);
        mysqli_stmt_bind_param($customization_stmt, "sssssssssi", $customer_name, $customer_email, $customer_address, $customer_phone, $dress_style, $fabric_type, $color, $neckline, $size, $quantity);

        if (mysqli_stmt_execute($customization_stmt)) {
            $_SESSION['order_message'] = 'Customization added successfully!';
            header('Location: customer_index.php?page=service&service_page=custom');
            exit();
        } else {
            error_log('Customization insert error: ' . mysqli_error($conn));
            echo json_encode(['status' => 'error', 'message' => 'Customization insert error: ' . mysqli_error($conn)]);
        }

        mysqli_stmt_close($customization_stmt);
    } else {
        error_log('Missing required fields: ' . print_r($_POST, true));
        echo json_encode(['status' => 'error', 'message' => 'Missing required fields']);
        exit();
    }

    mysqli_close($conn);
}
?>