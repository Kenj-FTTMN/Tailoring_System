<?php
// Start the session
session_start();

// Handle logout
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    // Destroy all session data
    session_destroy();
    
    // Clear session cookies
    if (isset($_COOKIE[session_name()])) {
        setcookie(session_name(), '', time()-3600, '/');
    }
    
    // Redirect to index.php
    header('Location: ../index.php');
    exit();
}

// Check if user is logged in and is a customer
if (!isset($_SESSION['user_id']) || !isset($_SESSION['user_type']) || $_SESSION['user_type'] !== 'customer') {
    header('Location: ../index.php');
    exit();
}

// Check if there's a message to display
if (isset($_SESSION['order_message'])) {
    $message = $_SESSION['order_message'];
    unset($_SESSION['order_message']); // Clear the message after displaying it
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">
  <title>Tailoring System</title>
  <meta name="description" content="">
  <meta name="keywords" content="">

  <!-- Favicons -->
  <link href="../assets/img/Tailoring.png" rel="icon">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link
    href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&display=swap"
    rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="../assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="../assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="../assets/css/main.css" rel="stylesheet">
</head>

<body class="index-page">

  <header id="header" class="header d-flex align-items-center sticky-top">
    <div class="container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

      <a href="index.html" class="logo d-flex align-items-center">
        <h1 class="sitename"><span>T</span>ailoring <span>S</span>ystem</h1>
      </a>

      <nav id="navmenu" class="navmenu">
        <ul>
          <li><a href="customer_index.php">Home</a></li>
          <li><a href="customer_index.php?page=service" class="<?php echo ($_GET['page'] ?? '') === 'service' ? 'active' : ''; ?>">Service</a></li>
          <li><a href="customer_index.php?page=message" class="<?php echo ($_GET['page'] ?? '') === 'message' ? 'active' : ''; ?>">Messages</a></li>
          <li><a href="customer_index.php?page=contact" class="<?php echo ($_GET['page'] ?? '') === 'contact' ? 'active' : ''; ?>">Contact</a></li>
          <li><a href="?action=logout">Logout</a></li>
        </ul>
        <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
      </nav>

        </div>
      </header>

      <main class="main">
        <section class="hero section light-background">
        <div class="row">
        <div class="col-lg-">
            <?php 
            if (isset($_GET['page'])) {
            $page = $_GET['page'];
            switch ($page) {
                case 'service':
                include 'service.php';
                break;
                case 'message':
                include 'message.php';
                break;
                case 'profile':
                include 'profile.php';
                break;
                case 'contact':
                include 'contact.php';
                break;
            }
            } else {
            ?>
                        <!-- Hero Section -->
                        <section id="hero" class="hero section light-background">
                        <div class="container position-relative" data-aos="fade-up" data-aos-delay="100">
                            <div class="row gy-5">
                            <div class="col-lg-6 order-2 order-lg-1 d-flex flex-column justify-content-center">
                                <h2>Tailoring System</h2>
                                <p>Stitched to Perfection, Styled for You!</p>
                                <div class="d-flex">
                                <a href="order.php" class="btn-order">Order Now!</a>
                                </div>
                            </div>
                            <div class="col-lg-4 order-1 order-lg-2">
                                <img src="../assets/img/Tailoring.png" alt="">
                            </div>
                            </div>
                        </div>
                        </section>
                        <!-- /Hero Section -->

                    <?php 
                    } 
                ?>
            </div>
        </div>
    </section>
  </main>

  <footer id="footer" class="footer light-background">

    <div class="container">
      <div class="social-links d-flex justify-content-center">
        <a href=""><i class="bi bi-twitter-x"></i></a>
        <a href=""><i class="bi bi-facebook"></i></a>
        <a href=""><i class="bi bi-instagram"></i></a>
        <a href=""><i class="bi bi-linkedin"></i></a>
      </div>
    </div>

  </footer>

  <!-- Scroll Top -->
  <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
      class="bi bi-arrow-up-short"></i></a>

  <!-- Preloader -->
  <div id="preloader"></div>

  <!-- Vendor JS Files -->
  <script src="../assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../assets/vendor/php-email-form/validate.js"></script>
  <script src="../assets/vendor/aos/aos.js"></script>
  <script src="../assets/vendor/glightbox/js/glightbox.min.js"></script>

  <!-- Main JS File -->
  <script src="../assets/js/main.js"></script>

  <?php if (isset($message)): ?>
    <div id="orderMessage" class="alert alert-success" role="alert">
        <?php echo $message; ?>
    </div>
  <?php endif; ?>

  <script>
    // Hide the message after 10 seconds
    setTimeout(function() {
        const message = document.getElementById('orderMessage');
        if (message) {
            message.style.display = 'none';
        }
    }, 10000); // 10000 milliseconds = 10 seconds
  </script>

</body>

</html>

