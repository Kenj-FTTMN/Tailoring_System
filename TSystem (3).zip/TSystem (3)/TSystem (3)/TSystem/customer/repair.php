<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
include('.././database/connection.php');

// Check if user is logged in
if (!isset($_SESSION['user_id'])) {
    header('Location: ../login.php');
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validate and sanitize input
        $first_name = mysqli_real_escape_string($conn, $_POST['firstName']);
        $last_name = mysqli_real_escape_string($conn, $_POST['lastName']);
        $email = mysqli_real_escape_string($conn, $_POST['email']);
        $phone_number = mysqli_real_escape_string($conn, $_POST['phone']);
        $garment_type = mysqli_real_escape_string($conn, $_POST['garmentType']);
        $repair_type = mysqli_real_escape_string($conn, $_POST['repairType']);
        $repair_description = mysqli_real_escape_string($conn, $_POST['description']);
        $preferred_date = mysqli_real_escape_string($conn, $_POST['appointmentDate']);
        $preferred_time = mysqli_real_escape_string($conn, $_POST['appointmentTime']);
        $additional_notes = mysqli_real_escape_string($conn, $_POST['additionalNotes'] ?? '');
        $user_id = $_SESSION['user_id'];

        // Insert into database
        $query = "INSERT INTO repair_appointments (
            first_name, last_name, email, phone_number,
            garment_type, repair_type, repair_description,
            preferred_date, preferred_time, additional_notes,
            status, user_id, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', ?, NOW())";

        $stmt = $conn->prepare($query);
        if (!$stmt) {
            throw new Exception("Prepare failed: " . $conn->error);
        }

        $stmt->bind_param("ssssssssssi",
            $first_name, $last_name, $email, $phone_number,
            $garment_type, $repair_type, $repair_description,
            $preferred_date, $preferred_time, $additional_notes,
            $user_id
        );

        if (!$stmt->execute()) {
            throw new Exception("Execute failed: " . $stmt->error);
        }

        $success = true;
        $stmt->close();
    } catch (Exception $e) {
        $error = $e->getMessage();
        error_log("Error in repair appointment submission: " . $error);
    }
}
?>
<section id="repair-section" class="repair section">
  <div class="container section-title text-center" data-aos="fade-up">
    <h2 class="mb-4">Schedule a Repair Appointment</h2>
    <p class="text-muted">Let our expert tailors restore your favorite garments</p>
  </div>

  <div class="container mt-4">
    <div class="row justify-content-center">
      <div class="col-md-8">
        <?php if (isset($success)): ?>
          <div class="alert alert-success alert-dismissible fade show" role="alert">
            Your repair appointment has been successfully scheduled! We will contact you soon.
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>

        <?php if (isset($error)): ?>
          <div class="alert alert-danger alert-dismissible fade show" role="alert">
            Error scheduling appointment: <?php echo htmlspecialchars($error); ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
          </div>
        <?php endif; ?>

        <div style="background-color: #f9f5ed; border-radius: 10px; padding: 30px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <form method="POST" class="needs-validation" novalidate>
            <!-- Personal Information -->
            <div class="row mb-4">
              <div class="col-md-6 mb-3">
                <label for="firstName" class="form-label">First Name</label>
                <input type="text" class="form-control" id="firstName" name="firstName" required>
              </div>
              <div class="col-md-6 mb-3">
                <label for="lastName" class="form-label">Last Name</label>
                <input type="text" class="form-control" id="lastName" name="lastName" required>
              </div>
              <div class="col-md-6 mb-3">
                <label for="email" class="form-label">Email</label>
                <input type="email" class="form-control" id="email" name="email" required>
              </div>
              <div class="col-md-6 mb-3">
                <label for="phone" class="form-label">Phone Number</label>
                <input type="tel" class="form-control" id="phone" name="phone" required>
              </div>
            </div>

            <!-- Repair Details -->
            <div class="mb-4">
              <h5 class="mb-3" style="color: #333;">Repair Details</h5>
              
              <div class="mb-3">
                <label for="garmentType" class="form-label">Type of Garment</label>
                <select class="form-select" id="garmentType" name="garmentType" required>
                  <option value="">Select Garment Type</option>
                  <option value="shirt">Shirt/Blouse</option>
                  <option value="pants">Pants/Trousers</option>
                  <option value="dress">Dress</option>
                  <option value="jacket">Jacket/Coat</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div class="mb-3">
                <label for="repairType" class="form-label">Type of Repair Needed</label>
                <select class="form-select" id="repairType" name="repairType" required>
                  <option value="">Select Repair Type</option>
                  <option value="alteration">Size Alteration</option>
                  <option value="zipper">Zipper Replacement</option>
                  <option value="buttons">Button Repair/Replacement</option>
                  <option value="tear">Tear/Hole Repair</option>
                  <option value="hemming">Hemming</option>
                  <option value="other">Other</option>
                </select>
              </div>

              <div class="mb-3">
                <label for="description" class="form-label">Describe the Repair Needed</label>
                <textarea class="form-control" id="description" name="description" rows="3" required 
                  placeholder="Please provide details about the repair needed and any specific instructions..."></textarea>
              </div>

              <div class="mb-3">
                <label for="appointmentDate" class="form-label">Preferred Appointment Date</label>
                <input type="date" class="form-control" id="appointmentDate" name="appointmentDate" required 
                  min="<?php echo date('Y-m-d'); ?>">
              </div>

              <div class="mb-3">
                <label for="appointmentTime" class="form-label">Preferred Time</label>
                <select class="form-select" id="appointmentTime" name="appointmentTime" required>
                  <option value="">Select Time</option>
                  <option value="morning">Morning (9AM - 12PM)</option>
                  <option value="afternoon">Afternoon (1PM - 4PM)</option>
                  <option value="evening">Evening (4PM - 7PM)</option>
                </select>
              </div>
            </div>

            <!-- Additional Notes -->
            <div class="mb-4">
              <label for="additionalNotes" class="form-label">Additional Notes (Optional)</label>
              <textarea class="form-control" id="additionalNotes" name="additionalNotes" rows="2" 
                placeholder="Any additional information you'd like us to know..."></textarea>
            </div>

            <button type="submit" class="btn w-100" style="background-color: #DCC3A1; color: white; font-weight: bold;">
              Schedule Appointment
            </button>
          </form>
        </div>

        <!-- Repair Service Note -->
        <div class="mt-4" style="background-color: #f9f5ed; border-radius: 10px; padding: 20px; border-left: 5px solid #DCC3A1; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
          <div class="d-flex align-items-start">
            <i class="fas fa-tools me-3 mt-1" style="color: #DCC3A1; font-size: 1.2rem;"></i>
            <div>
              <h5 style="color: #333; font-weight: 600; margin-bottom: 8px;">Our Repair Service</h5>
              <p style="color: #555; font-size: 1.1rem; line-height: 1.6; margin-bottom: 0;">
                We specialize in all types of clothing repairs and alterations. Our experienced tailors will assess your garment 
                and provide expert repair services to extend its life. Bring your beloved clothes back to life!
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>

<script>
  document.addEventListener("DOMContentLoaded", function () {
    // Form validation
    const form = document.querySelector('.needs-validation');
    form.addEventListener('submit', function(event) {
      if (!form.checkValidity()) {
        event.preventDefault();
        event.stopPropagation();
      }
      form.classList.add('was-validated');
    });

    // Date input validation
    const appointmentDate = document.getElementById('appointmentDate');
    if (appointmentDate) {
      // Set minimum date to today
      const today = new Date().toISOString().split('T')[0];
      appointmentDate.setAttribute('min', today);
      
      // Disable weekends
      appointmentDate.addEventListener('input', function() {
        const selected = new Date(this.value);
        const day = selected.getDay();
        
        if (day === 0 || day === 6) {
          alert('Please select a weekday for your appointment.');
          this.value = '';
        }
      });
    }

    // Add loading state to submit button
    form.addEventListener('submit', function(event) {
      if (form.checkValidity()) {
        const submitButton = this.querySelector('button[type="submit"]');
        submitButton.innerHTML = '<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Scheduling...';
        submitButton.disabled = true;
      }
    });
  });
</script>

<style>
  @import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css');

  .form-select, .form-control {
    border: 1px solid #DCC3A1;
  }

  .form-select:focus, .form-control:focus {
    border-color: #DCC3A1;
    box-shadow: 0 0 0 0.25rem rgba(220, 195, 161, 0.25);
  }

  .form-label {
    color: #555;
    font-weight: 500;
  }

  textarea.form-control {
    resize: vertical;
    min-height: 60px;
  }

  .repair-section {
    background-color: #fff;
    padding: 60px 0;
  }

  /* Add animation for form submission */
  @keyframes submitPulse {
    0% { transform: scale(1); }
    50% { transform: scale(1.05); }
    100% { transform: scale(1); }
  }

  button[type="submit"]:active {
    animation: submitPulse 0.3s ease-in-out;
  }
</style>
