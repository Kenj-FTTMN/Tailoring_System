<!-- Add CSS and JS links at the top -->
<link rel="stylesheet" href="../assets/css/main.css">

<!-- Order Options -->
<div class="row">
  <div class="col-md-4">
    <div class="order-options">
      <form action="process_order.php" method="POST" class="needs-validation" novalidate>
        <input type="hidden" name="garment_type" value="dress">
        
        <!-- Hidden fields for product details -->
        <input type="hidden" name="product_id" value="123"> <!-- Replace with actual product ID -->
        <input type="hidden" name="product_name" value="Sample Dress"> <!-- Replace with actual product name -->
        <input type="hidden" name="price" value="100.00"> <!-- Replace with actual price -->

        <div class="mb-3">
          <label for="dressStyle" class="form-label">Dress Style</label>
          <select class="form-select" id="dressStyle" name="dressStyle" required>
            <option value="">Select Style</option>
            <option value="shift">Shift</option>
            <option value="sheath">Sheath</option>
            <option value="wrapped">Wrapped</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="fabricType" class="form-label">Fabric Type</label>
          <select class="form-select" id="fabricType" name="fabricType" required>
            <option value="">Select Fabric</option>
            <option value="chiffon">Chiffon</option>
            <option value="linen">Linen</option>
            <option value="silk">Silk</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="color" class="form-label">Color</label>
          <select class="form-select" id="color" name="color" required>
            <option value="">Select Color</option>
            <option value="black">Black</option>
            <option value="rose">Rose</option>
            <option value="waterlily">Waterlily</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="neckline" class="form-label">Neckline</label>
          <select class="form-select" id="neckline" name="neckline" required>
            <option value="">Select Neckline</option>
            <option value="scoop">Scoop Neck</option>
            <option value="v">V-Neck</option>
            <option value="round">Round Neck</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="size" class="form-label">Size</label>
          <select class="form-select" id="size" name="size" required>
            <option value="">Select Size</option>
            <option value="XS">XS</option>
            <option value="S">S</option>
            <option value="M">M</option>
            <option value="L">L</option>
            <option value="XL">XL</option>
          </select>
        </div>

        <div class="mb-3">
          <label for="quantity" class="form-label">Quantity</label>
          <input type="number" class="form-control" id="quantity" name="order_quantity" min="1" required>
        </div>

        <div class="mb-3">
          <label for="customerName" class="form-label">Customer Name</label>
          <input type="text" class="form-control" id="customerName" name="customer_name" required>
        </div>

        <div class="mb-3">
          <label for="customerEmail" class="form-label">Customer Email</label>
          <input type="email" class="form-control" id="customerEmail" name="customer_email" required>
        </div>

        <div class="mb-3">
          <label for="customerAddress" class="form-label">Customer Address</label>
          <input type="text" class="form-control" id="customerAddress" name="customer_address" required>
        </div>

        <div class="mb-3">
          <label for="customerPhone" class="form-label">Customer Phone</label>
          <input type="text" class="form-control" id="customerPhone" name="customer_phone" required>
        </div>

        <button type="submit" class="btn w-100" style="background-color: #DCC3A1; color: white; font-weight: bold;">
          Add to Order
        </button>
      </form>
    </div>
  </div>

  <!-- Product Display -->
  <div class="col-md-8">
    <!-- Product Image and Colors -->
    <div class="mb-4">
      <div class="image-container" style="width: 400px; height: 400px; margin: 0 auto; display: flex; align-items: center; justify-content: center; background-color: #E6D7D9;">
        <img id="productImage" src="../assets/img/shift-black-u.png" alt="Dress" class="img-fluid" style="width: 300px; height: 300px; object-fit: contain; transition: opacity 0.3s ease-in-out; mix-blend-mode: multiply;">
      </div>

      <!-- Color Selection Buttons -->
      <div class="mt-4">
        <div class="d-flex justify-content-center">
          <div class="col-auto mx-2">
            <button class="color-button" style="background-color: #000000;" data-color="black"></button>
          </div>
          <div class="col-auto mx-2">
            <button class="color-button" style="background-color: #FF69B4;" data-color="rose"></button>
          </div>
          <div class="col-auto mx-2">
            <button class="color-button" style="background-color: #C4B1B6;" data-color="waterlily"></button>
          </div>
        </div>
      </div>

      <!-- Fabric Showcase -->
      <div class="mt-5">
        <h4 class="text-center mb-4" style="color: #333;">Available Fabrics</h4>
        <div class="d-flex justify-content-center">
          <div class="mx-4 text-center">
            <div class="fabric-circle mb-2" style="background-image: url('../assets/img/chiffon.jpg');" data-fabric="chiffon"></div>
            <p style="color: #555; font-weight: 500;">Chiffon</p>
          </div>
          <div class="mx-4 text-center">
            <div class="fabric-circle mb-2" style="background-image: url('../assets/img/linen.jpg');" data-fabric="linen"></div>
            <p style="color: #555; font-weight: 500;">Linen</p>
          </div>
          <div class="mx-4 text-center">
            <div class="fabric-circle mb-2" style="background-image: url('../assets/img/silk.jpg');" data-fabric="silk"></div>
            <p style="color: #555; font-weight: 500;">Silk</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Size Guide -->
    <div class="table-responsive mb-4" style="background-color: #f9f5ed; border-radius: 10px; padding: 20px;">
      <table class="table table-bordered mb-0">
        <thead class="text-center" style="background-color: #e9e2d7;">
          <tr>
            <th>MEASUREMENTS</th>
            <th>XS</th>
            <th>S</th>
            <th>M</th>
            <th>L</th>
            <th>XL</th>
          </tr>
        </thead>
        <tbody class="text-center">
          <tr>
            <td>BUST</td>
            <td>32"</td>
            <td>34"</td>
            <td>36"</td>
            <td>38"</td>
            <td>40"</td>
          </tr>
          <tr>
            <td>WAIST</td>
            <td>24"</td>
            <td>26"</td>
            <td>28"</td>
            <td>30"</td>
            <td>32"</td>
          </tr>
          <tr>
            <td>HIPS</td>
            <td>35"</td>
            <td>37"</td>
            <td>39"</td>
            <td>41"</td>
            <td>43"</td>
          </tr>
          <tr>
            <td>LENGTH</td>
            <td>38"</td>
            <td>39"</td>
            <td>40"</td>
            <td>41"</td>
            <td>42"</td>
          </tr>
        </tbody>
      </table>
    </div>

    <!-- Product Note -->
    <div class="mb-4" style="background-color: #f9f5ed; border-radius: 10px; padding: 20px; border-left: 5px solid #DCC3A1; box-shadow: 0 2px 4px rgba(0,0,0,0.1);">
      <div class="d-flex align-items-start">
        <i class="fas fa-info-circle me-3 mt-1" style="color: #DCC3A1; font-size: 1.2rem;"></i>
        <div>
          <h5 style="color: #333; font-weight: 600; margin-bottom: 8px;">Dress Features</h5>
          <p style="color: #555; font-size: 1.1rem; line-height: 1.6; margin-bottom: 0;">
            Our elegant dresses feature timeless designs with premium materials. Perfect for any special occasion or everyday wear.
          </p>
        </div>
      </div>
    </div>
  </div>
</div>

<script src="../assets/js/main.js"></script>

