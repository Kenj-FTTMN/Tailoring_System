<?php
require_once('../database/connection.php');

if (isset($_POST['btn_submit'])) {
    $name = mysqli_real_escape_string($con, $_POST["name"]);
    $email = mysqli_real_escape_string($con, $_POST["email"]);
    $message = mysqli_real_escape_string($con, $_POST["message"]);

    $sql = "INSERT INTO `message`(`name`, `email`, `message`) VALUES ('$name','$email','$message')";

    if ($con->query($sql) === TRUE) {
        echo "<script>alert('Message sent successfully!'); window.location.href='customer_index.php';</script>";
    } else {
        echo "<script>alert('Failed to send message');</script>";
    }
}
?>
<section class="contact section">
    <div class="container" data-aos="fade-up" data-aos-delay="100">
        <div class="row justify-content-center">
            <div class="col-lg-4" style="margin-top: 95px;">
            <div class="info-box text-center">
                <i class="bi bi-house-door" style="font-size: 2rem; color: #DCC3A1;"></i>
                <h3>Address</h3>
                <p>Cagayan de Oro City</p>
            </div>
            <div class="info-box mt-4 text-center">
                <i class="bi bi-telephone" style="font-size: 2rem; color: #DCC3A1;"></i>
                <h3>Phone</h3>
                <p>09999999999</p>
            </div>
            <div class="info-box mt-4 text-center">
                <i class="bi bi-envelope" style="font-size: 2rem; color: #DCC3A1;"></i>
                <h3>E-mail</h3>
                <p>example@email.com</p>
            </div>
            </div>
            <div class="col-lg-6">
            <div class="container section-title" data-aos="fade-up">
                <div class="form-box">
                <h2 style="font-size: 2.5rem; margin-bottom: -100px;">Leave Message</h2>
                </div>
            </div>
            <form method="post">
                <div class="mb-3">
                <input type="text" name="name" class="form-control" placeholder="Enter your Name" required>
                </div>
                <div class="mb-3">
                <input type="email" name="email" class="form-control" placeholder="Enter a valid email address" required>
                </div>
                <div class="mb-3">
                <textarea name="message" class="form-control" rows="10" placeholder="Enter your message" required></textarea>
                </div>
                <div class="text-center">
                <button type="submit" name="btn_submit" class="btn btn-primary" style="background-color: #DFC7A6; border-color: #F7F5F0;">Submit</button>
                </div>
            </form>
                </div>
            </div>
        </div>
</section>