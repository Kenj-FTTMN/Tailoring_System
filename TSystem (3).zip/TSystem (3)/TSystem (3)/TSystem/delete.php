<?php
include './database/connection.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    
    // Set deleted_at to the current timestamp
    $sql = "UPDATE `registration` SET `deleted_at` = NOW() WHERE `user_id` = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        echo "<script>alert('User  deleted successfully!'); window.location.href='admin/admin_index.php';</script>";
    } else {
        echo "<script>alert('Error deleting user.'); window.location.href='admin/admin_index.php';</script>";
    }

    $stmt->close();
    $conn->close();
}
?>